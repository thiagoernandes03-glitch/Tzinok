package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Gamepad
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameProfile
import com.example.ui.screens.GamesScreen
import com.example.ui.screens.HudEditorScreen
import com.example.ui.screens.SettingsAndInfoScreen
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberPrimaryCyan
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.viewmodel.KeyMapperViewModel

enum class MainTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    GAMES("Jogos & Mapeamento", Icons.Filled.Gamepad, Icons.Outlined.Gamepad),
    SETTINGS("Configurações & Info", Icons.Filled.Settings, Icons.Outlined.Settings)
}

@Composable
fun KeyMapperApp(viewModel: KeyMapperViewModel) {
    var selectedTab by remember { mutableStateOf(MainTab.GAMES) }
    var editingProfile by remember { mutableStateOf<GameProfile?>(null) }

    if (editingProfile != null) {
        BackHandler {
            editingProfile = null
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            if (editingProfile == null) {
                NavigationBar(
                    containerColor = CyberSurface,
                    contentColor = CyberTextPrimary,
                    tonalElevation = 4.dp,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("app_navigation_bar")
                ) {
                    MainTab.entries.forEach { tab ->
                        val isSelected = selectedTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.title
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = CyberDarkBg,
                                selectedTextColor = CyberPrimaryCyan,
                                indicatorColor = CyberPrimaryCyan,
                                unselectedIconColor = CyberTextMuted,
                                unselectedTextColor = CyberTextMuted
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (editingProfile != null) {
                // Editor HUD screen when user taps "Teclas"
                HudEditorScreen(
                    viewModel = viewModel,
                    onNavigateBack = { editingProfile = null },
                    onNavigateToArena = { editingProfile = null }
                )
            } else {
                when (selectedTab) {
                    MainTab.GAMES -> {
                        GamesScreen(
                            viewModel = viewModel,
                            onConfigureGame = { profile ->
                                editingProfile = profile
                            }
                        )
                    }
                    MainTab.SETTINGS -> {
                        SettingsAndInfoScreen(
                            viewModel = viewModel
                        )
                    }
                }
            }
        }
    }
}
