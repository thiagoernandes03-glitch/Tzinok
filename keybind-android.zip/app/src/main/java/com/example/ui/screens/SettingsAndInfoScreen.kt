package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.service.ShizukuStatus
import com.example.service.TouchInjectionMode
import com.example.ui.theme.CyberAccentAmber
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberPrimaryCyan
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceHighlight
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.viewmodel.KeyMapperViewModel

@Composable
fun SettingsAndInfoScreen(
    viewModel: KeyMapperViewModel
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val keyboards by viewModel.connectedKeyboards.collectAsState()
    val mice by viewModel.connectedMice.collectAsState()
    val hasKeyboard by viewModel.hasHardwareKeyboard.collectAsState()
    val hasMouse by viewModel.hasHardwareMouse.collectAsState()
    val shizukuStatus by viewModel.shizukuStatus.collectAsState()
    val injectionMode by viewModel.injectionMode.collectAsState()
    val lastLatency by viewModel.lastInputLatencyMs.collectAsState()

    var copiedCommand by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = CyberPrimaryCyan,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "CONFIGURAÇÕES & INFO",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = CyberPrimaryCyan
                    )
                    Text(
                        text = "Motor de Injeção, Shizuku e Informações do App",
                        fontSize = 11.sp,
                        color = CyberTextSecondary
                    )
                }
            }
        }

        // Card 1: Motor de Injeção de Toque & Shizuku ADB
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = CyberGreenActive, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("MOTOR DE INJEÇÃO", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                        }

                        Surface(
                            color = CyberSurfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Latência: ${lastLatency}ms",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberGreenActive,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Modo Shizuku ADB (Zero Lag ~1ms)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberTextPrimary
                            )
                            Text(
                                text = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) "Shizuku Conectado & Autorizado" else "Shizuku Inativo (Usando Acessibilidade)",
                                fontSize = 10.sp,
                                color = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) CyberGreenActive else CyberAccentAmber
                            )
                        }

                        Switch(
                            checked = injectionMode == TouchInjectionMode.SHIZUKU_ADB,
                            onCheckedChange = { isChecked ->
                                viewModel.setInjectionMode(if (isChecked) TouchInjectionMode.SHIZUKU_ADB else TouchInjectionMode.ACCESSIBILITY_SERVICE)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberDarkBg,
                                checkedTrackColor = CyberGreenActive,
                                uncheckedThumbColor = CyberTextMuted,
                                uncheckedTrackColor = CyberSurfaceHighlight
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Comando de Ativação via PC / Termux (Opcional):",
                        fontSize = 11.sp,
                        color = CyberTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    // ADB Command snippet for PC/Termux
                    Surface(
                        color = CyberDarkBg,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = CyberPrimaryCyan,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString("adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh"))
                                    copiedCommand = true
                                }
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copiar comando", tint = CyberPrimaryCyan, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    if (copiedCommand) {
                        Text("Comando copiado para a área de transferência!", fontSize = 10.sp, color = CyberGreenActive, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }

        // Card 2: Informações do Aplicativo & Hardware
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Itachi Logo Big Emblem
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = "Logo KeyMapper Pro",
                        modifier = Modifier
                            .size(88.dp)
                            .clip(CircleShape)
                            .border(2.dp, CyberPrimaryCyan, CircleShape)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "KeyMapper Pro",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = CyberPrimaryCyan,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = "Versão 1.0.0 (Edição Gamer Mangekyo)",
                        fontSize = 11.sp,
                        color = CyberTextSecondary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Hardware Peripherals Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = CyberSurfaceVariant,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Keyboard, contentDescription = null, tint = if (hasKeyboard) CyberPrimaryCyan else CyberTextMuted, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(if (hasKeyboard) "Teclado Conectado" else "Sem Teclado USB/BT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (hasKeyboard) CyberGreenActive else CyberTextMuted)
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            color = CyberSurfaceVariant,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Mouse, contentDescription = null, tint = if (hasMouse) CyberAccentOrange else CyberTextMuted, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(if (hasMouse) "Mouse Conectado" else "Sem Mouse USB/BT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (hasMouse) CyberGreenActive else CyberTextMuted)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "💡 O mapeamento de teclas, analógico (WASD), botão de vista e sensibilidades X & Y agora ficam integrados diretamente no Menu Flutuante sobre o jogo para máxima precisão e praticidade.",
                        fontSize = 11.sp,
                        color = CyberTextMuted,
                        lineHeight = 15.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
