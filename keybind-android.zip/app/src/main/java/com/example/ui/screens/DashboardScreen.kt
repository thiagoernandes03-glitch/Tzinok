package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameProfile
import com.example.service.ShizukuStatus
import com.example.service.TouchInjectionMode
import com.example.ui.components.CrosshairCanvas
import com.example.ui.theme.CyberAccentAmber
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderActive
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberPrimaryCyan
import com.example.ui.theme.CyberRedLaser
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceHighlight
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.viewmodel.KeyMapperViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: KeyMapperViewModel,
    onNavigateToEditor: () -> Unit,
    onNavigateToArena: () -> Unit,
    onNavigateToHardwareTester: () -> Unit,
    onNavigateToActivation: () -> Unit
) {
    val context = LocalContext.current
    val profiles by viewModel.profiles.collectAsState()
    val selectedProfile by viewModel.selectedProfile.collectAsState()
    val keyboards by viewModel.connectedKeyboards.collectAsState()
    val mice by viewModel.connectedMice.collectAsState()
    val hasKeyboard by viewModel.hasHardwareKeyboard.collectAsState()
    val hasMouse by viewModel.hasHardwareMouse.collectAsState()
    val shizukuStatus by viewModel.shizukuStatus.collectAsState()
    val injectionMode by viewModel.injectionMode.collectAsState()
    val isAccessibilityActive by viewModel.isAccessibilityActive.collectAsState()
    val isOverlayGranted by viewModel.isOverlayGranted.collectAsState()
    val lastLatency by viewModel.lastInputLatencyMs.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Title Header with Anime App Logo & Esports Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = "Logo KeyMapper Pro",
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, CyberPrimaryCyan, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "KEYMAPPER PRO",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = CyberPrimaryCyan,
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = "Motor Teclado & Mouse Gamer",
                            fontSize = 11.sp,
                            color = CyberTextSecondary
                        )
                    }
                }

                Surface(
                    color = CyberSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) CyberGreenActive else CyberAccentAmber)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) "SHIZUKU ADB" else "ACESSIBILIDADE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary
                        )
                    }
                }
            }
        }

        // Hardware Peripherals Status Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hardware_status_card")
                    .clickable { onNavigateToHardwareTester() },
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STATUS DO HARDWARE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextMuted,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Latência: ${lastLatency}ms",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CyberGreenActive
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Keyboard Chip
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = CyberSurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (hasKeyboard) CyberPrimaryCyan else CyberBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Keyboard,
                                    contentDescription = null,
                                    tint = if (hasKeyboard) CyberPrimaryCyan else CyberTextMuted,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (hasKeyboard) "Teclado Conectado" else "Teclado USB / BT",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberTextPrimary
                                    )
                                    Text(
                                        text = if (hasKeyboard) keyboards.firstOrNull()?.name?.take(18) ?: "Ativo" else "Aguardando conexão",
                                        fontSize = 10.sp,
                                        color = if (hasKeyboard) CyberGreenActive else CyberTextMuted
                                    )
                                }
                            }
                        }

                        // Mouse Chip
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = CyberSurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (hasMouse) CyberAccentOrange else CyberBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mouse,
                                    contentDescription = null,
                                    tint = if (hasMouse) CyberAccentOrange else CyberTextMuted,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (hasMouse) "Mouse Gamer" else "Mouse USB / BT",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberTextPrimary
                                    )
                                    Text(
                                        text = if (hasMouse) mice.firstOrNull()?.name?.take(18) ?: "Ativo" else "Aguardando conexão",
                                        fontSize = 10.sp,
                                        color = if (hasMouse) CyberGreenActive else CyberTextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Shizuku & Rootless ADB Integration Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("shizuku_banner_card"),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) CyberGreenActive else CyberAccentAmber
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) CyberGreenActive else CyberAccentAmber,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "MODO SHIZUKU (INJEÇÃO ADB)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberTextPrimary
                            )
                        }

                        IconButton(onClick = onNavigateToActivation) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Guia e Permissões",
                                tint = CyberPrimaryCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = when (shizukuStatus) {
                            ShizukuStatus.AUTHORIZED_AND_READY ->
                                "Shizuku 100% autorizado! Injeção direta de comandos de toque em jogos sem root e sem atraso de latência."
                            ShizukuStatus.WAITING_PERMISSION ->
                                "Serviço Shizuku detectado rodando. Clique abaixo para conceder permissão de injeção de toques ao KeyMapper."
                            ShizukuStatus.NOT_INSTALLED_OR_STOPPED ->
                                "Shizuku não iniciado. Você pode ativá-lo via Wireless Debugging/ADB ou usar o Serviço de Acessibilidade nativo."
                        },
                        fontSize = 12.sp,
                        color = CyberTextSecondary,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (shizukuStatus == ShizukuStatus.WAITING_PERMISSION) {
                            Button(
                                onClick = { viewModel.requestShizukuPermission() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberAccentAmber),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Autorizar Shizuku", fontWeight = FontWeight.Bold, color = CyberDarkBg)
                            }
                        } else if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) {
                            Button(
                                onClick = { viewModel.grantAllPermissionsViaShizuku() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceHighlight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyberGreenActive, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Conceder Permissões ADB", fontSize = 12.sp, color = CyberTextPrimary)
                            }
                        } else {
                            Button(
                                onClick = onNavigateToActivation,
                                colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceHighlight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Ver Guia de Ativação Shizuku", fontSize = 12.sp, color = CyberPrimaryCyan)
                            }
                        }

                        // Open Accessibility if needed
                        if (!isAccessibilityActive) {
                            Button(
                                onClick = {
                                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                    context.startActivity(intent)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Acessibilidade", fontSize = 11.sp, color = CyberTextSecondary)
                            }
                        }
                    }
                }
            }
        }

        // Selected Game Profile Hero
        item {
            selectedProfile?.let { profile ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberSurface),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberBorderActive)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = profile.name,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = CyberTextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    if (profile.isFavorite) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = null,
                                            tint = CyberAccentAmber,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${profile.genre} • ${profile.mappings.size} teclas mapeadas",
                                    fontSize = 11.sp,
                                    color = CyberTextSecondary
                                )
                            }

                            CrosshairCanvas(
                                style = profile.crosshairStyle,
                                colorHex = profile.crosshairColorHex,
                                sizeDp = 28
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action Buttons: Test Arena & Edit HUD
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onNavigateToArena,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_live_arena"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberPrimaryCyan
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = CyberDarkBg
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "TESTAR ARENA",
                                    fontWeight = FontWeight.Black,
                                    color = CyberDarkBg,
                                    fontSize = 13.sp
                                )
                            }

                            Button(
                                onClick = onNavigateToEditor,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_edit_hud"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberSurfaceHighlight
                                ),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = CyberPrimaryCyan
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "EDITAR HUD",
                                    fontWeight = FontWeight.Bold,
                                    color = CyberTextPrimary,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Game Profile Carousel Selector
        item {
            Text(
                text = "PERFIS DE JOGOS DISPONÍVEIS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = CyberTextMuted,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(profiles) { item ->
                    val isCurrent = selectedProfile?.id == item.id
                    Surface(
                        modifier = Modifier
                            .clickable { viewModel.selectProfile(item) }
                            .testTag("profile_item_${item.id}"),
                        color = if (isCurrent) CyberSurfaceHighlight else CyberSurface,
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isCurrent) CyberPrimaryCyan else CyberBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.Start
                        ) {
                            Text(
                                text = item.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) CyberPrimaryCyan else CyberTextPrimary
                            )
                            Text(
                                text = item.genre,
                                fontSize = 10.sp,
                                color = CyberTextSecondary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${item.mappings.size} Teclas • Sens: ${item.mouseSensitivityX}x",
                                fontSize = 10.sp,
                                color = CyberTextMuted
                            )
                        }
                    }
                }
            }
        }

        // Quick Sensitivity Sliders
        item {
            selectedProfile?.let { profile ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberSurface),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "AJUSTE RÁPIDO DO MOUSE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextMuted,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Sensitivity X
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Sensibilidade X (Horizontal)", fontSize = 12.sp, color = CyberTextPrimary)
                            Text(String.format("%.2f", profile.mouseSensitivityX), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberPrimaryCyan)
                        }
                        Slider(
                            value = profile.mouseSensitivityX,
                            onValueChange = { newX ->
                                viewModel.updateSensitivity(newX, profile.mouseSensitivityY, profile.adsSensitivityModifier, profile.antiRecoilPullDown)
                            },
                            valueRange = 0.2f..3.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberPrimaryCyan,
                                activeTrackColor = CyberPrimaryCyan
                            )
                        )

                        // Sensitivity Y
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Sensibilidade Y (Vertical)", fontSize = 12.sp, color = CyberTextPrimary)
                            Text(String.format("%.2f", profile.mouseSensitivityY), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberAccentOrange)
                        }
                        Slider(
                            value = profile.mouseSensitivityY,
                            onValueChange = { newY ->
                                viewModel.updateSensitivity(profile.mouseSensitivityX, newY, profile.adsSensitivityModifier, profile.antiRecoilPullDown)
                            },
                            valueRange = 0.2f..3.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberAccentOrange,
                                activeTrackColor = CyberAccentOrange
                            )
                        )

                        // Anti-Recoil Compensation
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Compensação Anti-Recoil (Puxar Mira)", fontSize = 12.sp, color = CyberTextPrimary)
                            Text("${(profile.antiRecoilPullDown * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberRedLaser)
                        }
                        Slider(
                            value = profile.antiRecoilPullDown,
                            onValueChange = { recoil ->
                                viewModel.updateSensitivity(profile.mouseSensitivityX, profile.mouseSensitivityY, profile.adsSensitivityModifier, recoil)
                            },
                            valueRange = 0.0f..0.5f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberRedLaser,
                                activeTrackColor = CyberRedLaser
                            )
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
