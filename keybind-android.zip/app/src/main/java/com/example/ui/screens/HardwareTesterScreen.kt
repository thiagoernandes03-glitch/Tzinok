package com.example.ui.screens

import android.view.KeyEvent
import android.view.MotionEvent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberAccentAmber
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberPrimaryCyan
import com.example.ui.theme.CyberRedLaser
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceHighlight
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.viewmodel.KeyMapperViewModel
import kotlinx.coroutines.delay

@Composable
fun HardwareTesterScreen(
    viewModel: KeyMapperViewModel,
    onNavigateBack: () -> Unit
) {
    val keyboards by viewModel.connectedKeyboards.collectAsState()
    val mice by viewModel.connectedMice.collectAsState()
    val lastLatency by viewModel.lastInputLatencyMs.collectAsState()
    val lastKeyInfo by viewModel.lastPressedKeyInfo.collectAsState()

    val focusRequester = remember { FocusRequester() }

    // Track pressed keys
    val pressedKeys = remember { mutableStateMapOf<String, Boolean>() }
    var mouseLeftClicked by remember { mutableStateOf(false) }
    var mouseRightClicked by remember { mutableStateOf(false) }
    var mouseMiddleClicked by remember { mutableStateOf(false) }
    var mouseScrollUpCount by remember { mutableIntStateOf(0) }
    var mouseScrollDownCount by remember { mutableIntStateOf(0) }
    var mouseDeltaX by remember { mutableIntStateOf(0) }
    var mouseDeltaY by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        delay(150)
        focusRequester.requestFocus()
    }

    // Keyboard rows definition
    val rowNumbers = listOf("ESC", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "DEL")
    val rowQwerty = listOf("TAB", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P")
    val rowAsdf = listOf("CAPS", "A", "S", "D", "F", "G", "H", "J", "K", "L", "ENTER")
    val rowZxcv = listOf("SHIFT", "Z", "X", "C", "V", "B", "N", "M", "CTRL", "ALT")
    val rowBottom = listOf("CTRL", "WIN", "ALT", "ESPAÇO", "ALT", "FN", "CTRL")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .padding(16.dp)
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                val code = keyEvent.nativeKeyEvent.keyCode
                val label = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
                val isDown = keyEvent.nativeKeyEvent.action == KeyEvent.ACTION_DOWN

                if (isDown) {
                    pressedKeys[label] = true
                }
                viewModel.handleKeyEvent(keyEvent.nativeKeyEvent)
                true
            },
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = CyberPrimaryCyan)
                    }
                    Column {
                        Text(
                            text = "CALIBRAÇÃO DE HARDWARE",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = CyberPrimaryCyan
                        )
                        Text(
                            text = "Teste em tempo real de Teclas, Botões e Latência",
                            fontSize = 11.sp,
                            color = CyberTextSecondary
                        )
                    }
                }

                IconButton(onClick = {
                    pressedKeys.clear()
                    mouseLeftClicked = false
                    mouseRightClicked = false
                    mouseMiddleClicked = false
                    mouseScrollUpCount = 0
                    mouseScrollDownCount = 0
                }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Limpar", tint = CyberTextMuted)
                }
            }
        }

        // Live Diagnostic Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = CyberGreenActive, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("TELEMETRIA DE ENTRADA", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                        }

                        Surface(color = CyberSurfaceVariant, shape = RoundedCornerShape(8.dp)) {
                            Text(
                                text = "Latência: ${lastLatency}ms",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberGreenActive,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = lastKeyInfo,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = CyberPrimaryCyan
                    )
                }
            }
        }

        // Mechanical Keyboard Visual Matrix
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Keyboard, contentDescription = null, tint = CyberPrimaryCyan, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("TESTE DA MATRIZ DO TECLADO", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                        }

                        Text(
                            text = "${pressedKeys.size} teclas registradas",
                            fontSize = 10.sp,
                            color = CyberTextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Keyboard Rows
                    KeyboardRowVisual(rowNumbers, pressedKeys)
                    Spacer(modifier = Modifier.height(6.dp))
                    KeyboardRowVisual(rowQwerty, pressedKeys)
                    Spacer(modifier = Modifier.height(6.dp))
                    KeyboardRowVisual(rowAsdf, pressedKeys)
                    Spacer(modifier = Modifier.height(6.dp))
                    KeyboardRowVisual(rowZxcv, pressedKeys)
                    Spacer(modifier = Modifier.height(6.dp))
                    KeyboardRowVisual(rowBottom, pressedKeys)

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Pressione as teclas no seu teclado USB ou Bluetooth para testar se estão funcionando e iluminá-las na tela.",
                        fontSize = 11.sp,
                        color = CyberTextMuted
                    )
                }
            }
        }

        // Mouse Buttons & DPI Diagnostic
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Mouse, contentDescription = null, tint = CyberAccentOrange, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("TESTE DE BOTÕES E SCROLL DO MOUSE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Left Button
                        MouseButtonBox(
                            title = "CLIQUE ESQUERDO",
                            sub = "Botão 1 / Disparo",
                            isPressed = mouseLeftClicked,
                            accentColor = CyberRedLaser,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { mouseLeftClicked = !mouseLeftClicked }
                        )

                        // Middle Button / Scroll
                        MouseButtonBox(
                            title = "SCROLL / MEIO",
                            sub = "Scroll: +$mouseScrollUpCount / -$mouseScrollDownCount",
                            isPressed = mouseMiddleClicked,
                            accentColor = CyberAccentAmber,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { mouseMiddleClicked = !mouseMiddleClicked }
                        )

                        // Right Button
                        MouseButtonBox(
                            title = "CLIQUE DIREITO",
                            sub = "Botão 2 / Mira",
                            isPressed = mouseRightClicked,
                            accentColor = CyberPrimaryCyan,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { mouseRightClicked = !mouseRightClicked }
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun KeyboardRowVisual(keys: List<String>, pressedMap: Map<String, Boolean>) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        keys.forEach { keyLabel ->
            val isTested = pressedMap.containsKey(keyLabel) || pressedMap.containsKey(keyLabel.lowercase())
            val animatedBg by animateColorAsState(
                targetValue = if (isTested) CyberPrimaryCyan else CyberSurfaceHighlight,
                label = "key_bg"
            )

            Surface(
                modifier = Modifier
                    .weight(if (keyLabel == "ESPAÇO") 3.5f else if (keyLabel.length > 3) 1.5f else 1f)
                    .height(32.dp),
                color = animatedBg,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isTested) CyberPrimaryCyan else CyberBorder
                )
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = keyLabel,
                        fontSize = if (keyLabel.length > 3) 8.sp else 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isTested) CyberDarkBg else CyberTextPrimary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun MouseButtonBox(
    title: String,
    sub: String,
    isPressed: Boolean,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.height(72.dp),
        color = if (isPressed) accentColor.copy(alpha = 0.25f) else CyberSurfaceVariant,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (isPressed) accentColor else CyberBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isPressed) accentColor else CyberTextPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = sub,
                fontSize = 9.sp,
                color = CyberTextMuted,
                textAlign = TextAlign.Center
            )
        }
    }
}
