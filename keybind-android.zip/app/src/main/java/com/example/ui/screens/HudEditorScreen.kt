package com.example.ui.screens

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.KeyMappingItem
import com.example.model.MappingType
import com.example.ui.components.CrosshairCanvas
import com.example.ui.components.VirtualHudOverlay
import com.example.ui.theme.CyberAccentAmber
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderActive
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberPrimaryCyan
import com.example.ui.theme.CyberRedLaser
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceHighlight
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.viewmodel.KeyMapperViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HudEditorScreen(
    viewModel: KeyMapperViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToArena: () -> Unit
) {
    val selectedProfile by viewModel.selectedProfile.collectAsState()
    val profiles by viewModel.profiles.collectAsState()

    var selectedItemForEdit by remember { mutableStateOf<KeyMappingItem?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedBackgroundTheme by remember { mutableStateOf("GRID") } // "GRID", "CYBER", "FPS_HUD"

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
    ) {
        // Game screen background simulation
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    when (selectedBackgroundTheme) {
                        "CYBER" -> Brush.radialGradient(
                            colors = listOf(CyberSurfaceHighlight, CyberDarkBg)
                        )
                        "FPS_HUD" -> Brush.verticalGradient(
                            colors = listOf(Color(0xFF0F1B2B), Color(0xFF070B10))
                        )
                        else -> Brush.radialGradient(
                            colors = listOf(Color(0xFF141F30), CyberDarkBg)
                        )
                    }
                )
        )

        // Center crosshair reference
        selectedProfile?.let { profile ->
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CrosshairCanvas(
                    style = profile.crosshairStyle,
                    colorHex = profile.crosshairColorHex,
                    sizeDp = profile.crosshairSizeDp
                )
            }
        }

        // Virtual HUD Buttons Layer
        selectedProfile?.let { profile ->
            VirtualHudOverlay(
                mappings = profile.mappings,
                isEditMode = true,
                activeKeys = emptySet(),
                isFiring = false,
                isAiming = false,
                joystickOffset = Offset.Zero,
                selectedMappingId = selectedItemForEdit?.id,
                onMappingSelected = { item ->
                    selectedItemForEdit = item
                },
                onPositionChanged = { id, xRatio, yRatio ->
                    viewModel.updateMappingPosition(id, xRatio, yRatio)
                }
            )
        }

        // Top Toolbar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            color = CyberSurface.copy(alpha = 0.92f),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = CyberPrimaryCyan)
                    }
                    Column {
                        Text(
                            text = "EDITOR DE HUD",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = CyberPrimaryCyan
                        )
                        Text(
                            text = "${selectedProfile?.name ?: "Perfil"} (${selectedProfile?.mappings?.size ?: 0} botões)",
                            fontSize = 10.sp,
                            color = CyberTextSecondary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Reset Profile Button
                    IconButton(
                        onClick = {
                            selectedProfile?.let { viewModel.resetProfileToDefault(it.id) }
                        }
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Restaurar Padrão", tint = CyberTextMuted)
                    }

                    // Go to Live Arena
                    Button(
                        onClick = onNavigateToArena,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPrimaryCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("editor_test_arena_btn")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CyberDarkBg, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Testar", fontWeight = FontWeight.Bold, color = CyberDarkBg, fontSize = 12.sp)
                    }
                }
            }
        }

        // Bottom Helper Bar / Hint
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp, start = 16.dp, end = 16.dp),
            color = CyberSurface.copy(alpha = 0.9f),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Arraste os botões para reposicionar na tela. Toque em qualquer tecla para configurar.",
                    fontSize = 11.sp,
                    color = CyberTextSecondary,
                    modifier = Modifier.weight(1f)
                )

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceHighlight),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimaryCyan),
                    modifier = Modifier.testTag("btn_add_key")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = CyberPrimaryCyan, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ Tecla", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberPrimaryCyan)
                }
            }
        }
    }

    // Modal Dialog: Edit Mapping Button
    selectedItemForEdit?.let { item ->
        EditMappingDialog(
            item = item,
            onDismiss = { selectedItemForEdit = null },
            onSave = { newKey, newLabel, newRadius ->
                viewModel.updateMappingKey(item.id, newKey, newLabel)
                viewModel.updateMappingRadius(item.id, newRadius)
                selectedItemForEdit = null
            },
            onDelete = {
                viewModel.deleteMapping(item.id)
                selectedItemForEdit = null
            }
        )
    }

    // Modal Dialog: Add New Mapping Button
    if (showAddDialog) {
        AddMappingDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { label, type, keyCode, displayKey ->
                viewModel.addMapping(label, type, keyCode, displayKey)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun EditMappingDialog(
    item: KeyMappingItem,
    onDismiss: () -> Unit,
    onSave: (Int, String, Float) -> Unit,
    onDelete: () -> Unit
) {
    var displayKey by remember { mutableStateOf(item.displayKey) }
    var keyCode by remember { mutableIntStateOf(item.keyCode) }
    var radius by remember { mutableFloatStateOf(item.radiusRatio) }

    val quickKeys = listOf(
        Pair("L-CLICK", KeyMappingItem.KEY_CODE_MOUSE_LEFT),
        Pair("R-CLICK", KeyMappingItem.KEY_CODE_MOUSE_RIGHT),
        Pair("ESPAÇO", KeyEvent.KEYCODE_SPACE),
        Pair("SHIFT", KeyEvent.KEYCODE_SHIFT_LEFT),
        Pair("CTRL", KeyEvent.KEYCODE_CTRL_LEFT),
        Pair("W", KeyEvent.KEYCODE_W),
        Pair("A", KeyEvent.KEYCODE_A),
        Pair("S", KeyEvent.KEYCODE_S),
        Pair("D", KeyEvent.KEYCODE_D),
        Pair("R", KeyEvent.KEYCODE_R),
        Pair("F", KeyEvent.KEYCODE_F),
        Pair("C", KeyEvent.KEYCODE_C),
        Pair("Z", KeyEvent.KEYCODE_Z),
        Pair("Q", KeyEvent.KEYCODE_Q),
        Pair("E", KeyEvent.KEYCODE_E),
        Pair("TAB", KeyEvent.KEYCODE_TAB),
        Pair("1", KeyEvent.KEYCODE_1),
        Pair("2", KeyEvent.KEYCODE_2),
        Pair("3", KeyEvent.KEYCODE_3),
        Pair("4", KeyEvent.KEYCODE_4),
        Pair("M", KeyEvent.KEYCODE_M)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        title = {
            Text(
                text = "Editar Botão: ${item.label}",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = CyberPrimaryCyan
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Tecla Atual Mapeada:",
                    fontSize = 12.sp,
                    color = CyberTextSecondary
                )

                Surface(
                    color = CyberSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimaryCyan),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = displayKey,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 16.dp)
                    )
                }

                Text(
                    text = "Selecione uma tecla de atalho:",
                    fontSize = 11.sp,
                    color = CyberTextMuted
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(quickKeys) { (label, code) ->
                        Surface(
                            modifier = Modifier.clickable {
                                displayKey = label
                                keyCode = code
                            },
                            color = if (keyCode == code) CyberPrimaryCyan else CyberSurfaceHighlight,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (keyCode == code) CyberDarkBg else CyberTextPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Tamanho do Botão HUD: ${(radius * 100).toInt()}%",
                    fontSize = 11.sp,
                    color = CyberTextSecondary
                )
                Slider(
                    value = radius,
                    onValueChange = { radius = it },
                    valueRange = 0.04f..0.20f,
                    colors = SliderDefaults.colors(thumbColor = CyberPrimaryCyan, activeTrackColor = CyberPrimaryCyan)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(keyCode, displayKey, radius) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimaryCyan)
            ) {
                Text("Salvar", color = CyberDarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Row {
                TextButton(
                    onClick = onDelete,
                    colors = ButtonDefaults.textButtonColors(contentColor = CyberRedLaser)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Remover")
                }
                TextButton(onClick = onDismiss) {
                    Text("Cancelar", color = CyberTextSecondary)
                }
            }
        }
    )
}

@Composable
fun AddMappingDialog(
    onDismiss: () -> Unit,
    onAdd: (String, MappingType, Int, String) -> Unit
) {
    var label by remember { mutableStateOf("Nova Ação") }
    var selectedType by remember { mutableStateOf(MappingType.BUTTON) }
    var keyCode by remember { mutableIntStateOf(KeyEvent.KEYCODE_E) }
    var displayKey by remember { mutableStateOf("E") }

    val presetTypes = listOf(
        Triple("Botão Simples", MappingType.BUTTON, KeyEvent.KEYCODE_E to "E"),
        Triple("Joystick WASD", MappingType.DPAD_WASD, KeyEvent.KEYCODE_W to "WASD"),
        Triple("Mira FPS (Mouse Look)", MappingType.MOUSE_LOOK, KeyEvent.KEYCODE_GRAVE to "MIRA (~)"),
        Triple("Disparo (L-Click)", MappingType.FIRE_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_LEFT to "L-CLICK"),
        Triple("Mira Óptica (R-Click)", MappingType.AIM_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_RIGHT to "R-CLICK")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        title = {
            Text(
                text = "Adicionar Novo Mapeamento",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = CyberPrimaryCyan
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Tipo de Controle:",
                    fontSize = 12.sp,
                    color = CyberTextSecondary
                )

                presetTypes.forEach { (title, type, keyPair) ->
                    val isSelected = selectedType == type
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedType = type
                                label = title
                                keyCode = keyPair.first
                                displayKey = keyPair.second
                            },
                        color = if (isSelected) CyberSurfaceHighlight else CyberSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) CyberPrimaryCyan else CyberBorder
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) CyberPrimaryCyan else CyberTextPrimary
                            )
                            Text(
                                text = keyPair.second,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberAccentAmber
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onAdd(label, selectedType, keyCode, displayKey) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimaryCyan)
            ) {
                Text("Adicionar ao HUD", color = CyberDarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = CyberTextSecondary)
            }
        }
    )
}
