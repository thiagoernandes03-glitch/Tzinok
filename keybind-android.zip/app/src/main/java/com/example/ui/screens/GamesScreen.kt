package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.GameProfile
import com.example.service.ShizukuStatus
import com.example.ui.theme.CyberAccentAmber
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderActive
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberPrimaryCyan
import com.example.ui.theme.CyberRedLaser
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceHighlight
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.viewmodel.KeyMapperViewModel

@Composable
fun GamesScreen(
    viewModel: KeyMapperViewModel,
    onConfigureGame: (GameProfile) -> Unit
) {
    val context = LocalContext.current
    val profiles by viewModel.profiles.collectAsState()
    val shizukuStatus by viewModel.shizukuStatus.collectAsState()
    val isAccessibilityActive by viewModel.isAccessibilityActive.collectAsState()
    val isOverlayGranted by viewModel.isOverlayGranted.collectAsState()

    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val isBatteryIgnored = powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false

    var showAddGameDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header with Itachi Logo
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = "Logo KeyMapper Pro",
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, CyberPrimaryCyan, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "KEYMAPPER PRO",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = CyberPrimaryCyan,
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = "Mapeador de Teclado & Mouse Gamer",
                            fontSize = 11.sp,
                            color = CyberTextSecondary
                        )
                    }
                }

                Surface(
                    color = CyberSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                ) {
                    Text(
                        text = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) "SHIZUKU ATIVO" else "MODO PADRÃO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) CyberGreenActive else CyberAccentAmber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Section: Permissões Principais (No início da Aba 1)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("permissions_hero_card"),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PERMISSÕES PRINCIPAIS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextMuted,
                            letterSpacing = 1.sp
                        )

                        Text(
                            text = if (isOverlayGranted && (isAccessibilityActive || shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY)) "PRONTO P/ JOGAR" else "PENDENTE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isOverlayGranted && (isAccessibilityActive || shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY)) CyberGreenActive else CyberAccentAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Grid of 3 quick permissions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Sobreposição
                        PermissionStatusChip(
                            title = "Sobreposição",
                            isGranted = isOverlayGranted,
                            icon = Icons.Default.Layers,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                }
                        )

                        // 2. Shizuku ADB
                        PermissionStatusChip(
                            title = "Shizuku ADB",
                            isGranted = shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY,
                            icon = Icons.Default.Bolt,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    if (shizukuStatus == ShizukuStatus.WAITING_PERMISSION) {
                                        viewModel.requestShizukuPermission()
                                    } else {
                                        viewModel.refreshShizukuStatus()
                                    }
                                }
                        )

                        // 3. Acessibilidade
                        PermissionStatusChip(
                            title = "Acessibilidade",
                            isGranted = isAccessibilityActive,
                            icon = Icons.Default.TouchApp,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                    context.startActivity(intent)
                                }
                        )
                    }

                    // 1-Click Super Grant via Shizuku button if authorized
                    if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                viewModel.grantAllPermissionsViaShizuku()
                                Toast.makeText(context, "Permissões concedidas com sucesso via Shizuku ADB!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberPrimaryCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = CyberDarkBg, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Conceder Permissões via Shizuku (1-Clique)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = CyberDarkBg
                            )
                        }
                    } else if (shizukuStatus == ShizukuStatus.WAITING_PERMISSION) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.requestShizukuPermission() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberAccentAmber),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Autorizar Shizuku Agora", fontWeight = FontWeight.Bold, color = CyberDarkBg, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Floating HUD Tutorial Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceHighlight),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimaryCyan.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = null,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .border(1.dp, CyberPrimaryCyan, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "MENU FLUTUANTE NO JOGO",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = CyberPrimaryCyan
                        )
                        Text(
                            text = "Toque no ícone flutuante sobre o jogo para abrir a barra e adicionar o Analógico (WASD), Botão de Vista (Sensibilidade X & Y), Disparo ou mover teclas!",
                            fontSize = 10.sp,
                            color = CyberTextSecondary,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        // Section Title & Add Game Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SEUS JOGOS MAPEADOS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberTextMuted,
                    letterSpacing = 1.sp
                )

                Button(
                    onClick = { showAddGameDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceHighlight),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimaryCyan),
                    modifier = Modifier.testTag("btn_add_new_game")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = CyberPrimaryCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ Adicionar Jogo", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberPrimaryCyan)
                }
            }
        }

        // List of Games Cards
        items(profiles) { game ->
            GameCardItem(
                game = game,
                onLaunchGameWithOverlay = {
                    viewModel.selectProfile(game)
                    viewModel.launchGameWithOverlay(context, game)
                    Toast.makeText(context, "Iniciando sobreposição para ${game.name}!", Toast.LENGTH_SHORT).show()
                },
                onConfigure = {
                    viewModel.selectProfile(game)
                    onConfigureGame(game)
                },
                onStopOverlay = {
                    viewModel.stopFloatingOverlay(context)
                    Toast.makeText(context, "Sobreposição encerrada.", Toast.LENGTH_SHORT).show()
                },
                onDelete = {
                    viewModel.deleteProfile(game.id)
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Modal to add a new game
    if (showAddGameDialog) {
        AddGameDialog(
            onDismiss = { showAddGameDialog = false },
            onAddGame = { name, packageName, genre ->
                viewModel.createNewProfile(name, genre, packageName)
                showAddGameDialog = false
            }
        )
    }
}

@Composable
fun PermissionStatusChip(
    title: String,
    isGranted: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = CyberSurfaceVariant,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isGranted) CyberGreenActive.copy(alpha = 0.6f) else CyberBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isGranted) CyberGreenActive else CyberAccentAmber,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = CyberTextPrimary
            )
            Text(
                text = if (isGranted) "ATIVO" else "CONCEDER",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (isGranted) CyberGreenActive else CyberAccentAmber
            )
        }
    }
}

@Composable
fun GameCardItem(
    game: GameProfile,
    onLaunchGameWithOverlay: () -> Unit,
    onConfigure: () -> Unit,
    onStopOverlay: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("game_card_${game.id}"),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderActive)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = CyberSurfaceHighlight,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.size(42.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Gamepad,
                                contentDescription = null,
                                tint = CyberPrimaryCyan,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = game.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary
                        )
                        Text(
                            text = "${game.genre} • ${game.mappings.size} Teclas mapeadas",
                            fontSize = 11.sp,
                            color = CyberTextSecondary
                        )
                    }
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Excluir jogo",
                        tint = CyberTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Sensitivities summary row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Mira (Vista): Sens X: ${String.format("%.2f", game.mouseSensitivityX)} | Sens Y: ${String.format("%.2f", game.mouseSensitivityY)}",
                    fontSize = 11.sp,
                    color = CyberAccentOrange,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Trava Mira: ${game.cursorLockKey}",
                    fontSize = 10.sp,
                    color = CyberTextMuted
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Primary Launch with Overlay Button
                Button(
                    onClick = onLaunchGameWithOverlay,
                    modifier = Modifier
                        .weight(1.8f)
                        .testTag("btn_launch_${game.id}"),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimaryCyan),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CyberDarkBg, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "ENTRAR NO JOGO",
                        fontWeight = FontWeight.Black,
                        color = CyberDarkBg,
                        fontSize = 12.sp
                    )
                }

                // Configure Mapping Button
                Button(
                    onClick = onConfigure,
                    modifier = Modifier.weight(1.1f),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceHighlight),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = CyberPrimaryCyan, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Ajustar",
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary,
                        fontSize = 12.sp
                    )
                }

                // Stop overlay quick button
                IconButton(onClick = onStopOverlay) {
                    Icon(Icons.Default.Stop, contentDescription = "Parar sobreposição", tint = CyberRedLaser)
                }
            }
        }
    }
}

@Composable
fun AddGameDialog(
    onDismiss: () -> Unit,
    onAddGame: (String, String, String) -> Unit
) {
    var gameName by remember { mutableStateOf("") }
    var packageName by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("Ação / FPS") }

    val popularSuggestions = listOf(
        Pair("Free Fire MAX", "com.dts.freefireth"),
        Pair("PUBG Mobile", "com.tencent.ig"),
        Pair("Call of Duty: Mobile", "com.activision.callofduty.shooter"),
        Pair("Minecraft", "com.mojang.minecraftpe"),
        Pair("Brawl Stars", "com.supercell.brawlstars"),
        Pair("Roblox", "com.roblox.client"),
        Pair("League of Legends: Wild Rift", "com.riotgames.league.wildrift")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        title = {
            Text(
                text = "Adicionar Jogo ao Mapeador",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = CyberPrimaryCyan
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = gameName,
                    onValueChange = { gameName = it },
                    label = { Text("Nome do Jogo") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = packageName,
                    onValueChange = { packageName = it },
                    label = { Text("Nome do Pacote (ex: com.dts.freefireth)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Ou escolha uma sugestão rápida:",
                    fontSize = 11.sp,
                    color = CyberTextMuted
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    popularSuggestions.take(4).forEach { (sugName, sugPkg) ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    gameName = sugName
                                    packageName = sugPkg
                                },
                            color = CyberSurfaceHighlight,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = sugName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = CyberPrimaryCyan,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (gameName.isNotBlank()) {
                        onAddGame(gameName, packageName.ifBlank { "com.game.${gameName.lowercase().replace(" ", "")}" }, genre)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimaryCyan)
            ) {
                Text("Adicionar", color = CyberDarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = CyberTextSecondary)
            }
        }
    )
}
