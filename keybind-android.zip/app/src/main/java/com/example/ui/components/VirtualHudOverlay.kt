package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Adjust
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.ControlCamera
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.KeyMappingItem
import com.example.model.MappingType
import com.example.ui.theme.CyberAccentAmber
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberPrimaryCyan
import com.example.ui.theme.CyberRedLaser
import com.example.ui.theme.CyberSurface

@Composable
fun VirtualHudOverlay(
    mappings: List<KeyMappingItem>,
    isEditMode: Boolean,
    activeKeys: Set<Int>,
    isFiring: Boolean,
    isAiming: Boolean,
    joystickOffset: Offset,
    modifier: Modifier = Modifier,
    selectedMappingId: String? = null,
    onMappingSelected: ((KeyMappingItem) -> Unit)? = null,
    onPositionChanged: ((String, Float, Float) -> Unit)? = null
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val containerWidth = constraints.maxWidth.toFloat()
        val containerHeight = constraints.maxHeight.toFloat()

        for (item in mappings) {
            val isSelected = selectedMappingId == item.id
            val isMouseLeft = item.keyCode == KeyMappingItem.KEY_CODE_MOUSE_LEFT
            val isMouseRight = item.keyCode == KeyMappingItem.KEY_CODE_MOUSE_RIGHT
            val isPressed = when {
                isMouseLeft -> isFiring
                isMouseRight -> isAiming
                else -> activeKeys.contains(item.keyCode)
            }

            // Calculate pixel position
            var currentXRatio by remember(item.id, item.posXRatio) { mutableFloatStateOf(item.posXRatio) }
            var currentYRatio by remember(item.id, item.posYRatio) { mutableFloatStateOf(item.posYRatio) }

            val pixelX = currentXRatio * containerWidth
            val pixelY = currentYRatio * containerHeight

            // Size calculation
            val baseSize = (item.radiusRatio * 2f * containerWidth.coerceAtMost(containerHeight))
                .coerceIn(48f, 150f)

            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            (pixelX - baseSize / 2f).toInt(),
                            (pixelY - baseSize / 2f).toInt()
                        )
                    }
                    .size(baseSize.dp)
                    .testTag("hud_button_${item.id}")
                    .then(
                        if (isEditMode) {
                            Modifier
                                .pointerInput(item.id, containerWidth, containerHeight) {
                                    detectDragGestures(
                                        onDragEnd = {
                                            onPositionChanged?.invoke(item.id, currentXRatio, currentYRatio)
                                        }
                                    ) { change, dragAmount ->
                                        change.consume()
                                        currentXRatio = ((pixelX + dragAmount.x) / containerWidth).coerceIn(0.04f, 0.96f)
                                        currentYRatio = ((pixelY + dragAmount.y) / containerHeight).coerceIn(0.04f, 0.96f)
                                        onPositionChanged?.invoke(item.id, currentXRatio, currentYRatio)
                                    }
                                }
                                .clickable { onMappingSelected?.invoke(item) }
                        } else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                when (item.type) {
                    MappingType.DPAD_WASD -> {
                        WasdStickHud(
                            item = item,
                            isEditMode = isEditMode,
                            isSelected = isSelected,
                            isPressed = isPressed,
                            joystickOffset = joystickOffset
                        )
                    }
                    MappingType.MOUSE_LOOK -> {
                        MouseLookHud(
                            item = item,
                            isEditMode = isEditMode,
                            isSelected = isSelected
                        )
                    }
                    MappingType.FIRE_BUTTON -> {
                        ActionButtonHud(
                            item = item,
                            isEditMode = isEditMode,
                            isSelected = isSelected,
                            isPressed = isPressed,
                            accentColor = CyberRedLaser,
                            icon = Icons.Default.Adjust
                        )
                    }
                    MappingType.AIM_BUTTON -> {
                        ActionButtonHud(
                            item = item,
                            isEditMode = isEditMode,
                            isSelected = isSelected,
                            isPressed = isPressed,
                            accentColor = CyberAccentAmber,
                            icon = Icons.Default.CenterFocusStrong
                        )
                    }
                    else -> {
                        ActionButtonHud(
                            item = item,
                            isEditMode = isEditMode,
                            isSelected = isSelected,
                            isPressed = isPressed,
                            accentColor = CyberPrimaryCyan,
                            icon = null
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WasdStickHud(
    item: KeyMappingItem,
    isEditMode: Boolean,
    isSelected: Boolean,
    isPressed: Boolean,
    joystickOffset: Offset
) {
    val borderColor = if (isSelected) CyberGreenActive else if (isPressed) CyberPrimaryCyan else CyberBorder
    val bgAlpha = if (isPressed) 0.5f else 0.25f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(CircleShape)
            .background(CyberDarkBg.copy(alpha = bgAlpha))
            .border(if (isSelected) 2.dp else 1.dp, borderColor, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        // D-Pad Crosshair lines
        Icon(
            imageVector = Icons.Default.Gamepad,
            contentDescription = null,
            tint = if (isPressed) CyberPrimaryCyan else Color.White.copy(alpha = 0.4f),
            modifier = Modifier.size(24.dp)
        )

        // Internal stick knob moving with WASD
        val knobOffsetX = (joystickOffset.x * 20f).dp
        val knobOffsetY = (joystickOffset.y * 20f).dp

        Box(
            modifier = Modifier
                .offset(knobOffsetX, knobOffsetY)
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            if (isPressed) CyberPrimaryCyan else CyberPrimaryCyan.copy(alpha = 0.6f),
                            CyberDarkBg.copy(alpha = 0.8f)
                        )
                    )
                )
                .border(1.dp, CyberPrimaryCyan, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "WASD",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
fun MouseLookHud(
    item: KeyMappingItem,
    isEditMode: Boolean,
    isSelected: Boolean
) {
    val borderColor = if (isSelected) CyberGreenActive else CyberAccentOrange

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(CircleShape)
            .background(CyberDarkBg.copy(alpha = 0.2f))
            .border(1.dp, borderColor, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.ControlCamera,
            contentDescription = null,
            tint = CyberAccentOrange.copy(alpha = 0.7f),
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = item.displayKey,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.offset(y = 18.dp)
        )
    }
}

@Composable
fun ActionButtonHud(
    item: KeyMappingItem,
    isEditMode: Boolean,
    isSelected: Boolean,
    isPressed: Boolean,
    accentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector?
) {
    val animatedBg by animateColorAsState(
        targetValue = if (isPressed) accentColor.copy(alpha = 0.7f) else CyberDarkBg.copy(alpha = 0.35f),
        label = "hud_bg"
    )
    val borderColor = if (isSelected) CyberGreenActive else if (isPressed) accentColor else accentColor.copy(alpha = 0.6f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(CircleShape)
            .background(animatedBg)
            .border(if (isSelected) 2.5.dp else 1.5.dp, borderColor, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isPressed) Color.White else accentColor,
                modifier = Modifier.size(18.dp)
            )
        }

        Text(
            text = item.displayKey,
            fontSize = if (item.displayKey.length > 4) 9.sp else 11.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isPressed) Color.White else Color.White.copy(alpha = 0.95f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 2.dp)
        )
    }
}
