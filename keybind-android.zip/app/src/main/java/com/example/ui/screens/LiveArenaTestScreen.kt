package com.example.ui.screens

import android.app.Activity
import android.os.Build
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.KeyMappingItem
import com.example.service.ShizukuStatus
import com.example.service.TouchInjectionMode
import com.example.ui.components.CrosshairCanvas
import com.example.ui.components.VirtualHudOverlay
import com.example.ui.theme.CyberAccentAmber
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderActive
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberPrimaryCyan
import com.example.ui.theme.CyberRedLaser
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceHighlight
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.viewmodel.KeyMapperViewModel
import kotlinx.coroutines.delay

data class HitTarget(
    val id: Int,
    val xRatio: Float,
    val yRatio: Float,
    val isHit: Boolean = false
)

@Composable
fun LiveArenaTestScreen(
    viewModel: KeyMapperViewModel,
    onNavigateBack: () -> Unit
) {
    val view = LocalView.current
    val context = LocalContext.current

    val selectedProfile by viewModel.selectedProfile.collectAsState()
    val isPointerCaptured by viewModel.isPointerCaptured.collectAsState()
    val crosshairPos by viewModel.crosshairPosition.collectAsState()
    val joystickOffset by viewModel.joystickOffset.collectAsState()
    val activeKeys by viewModel.activeKeysDown.collectAsState()
    val isFiring by viewModel.isFiring.collectAsState()
    val isAiming by viewModel.isAiming.collectAsState()
    val telemetryList by viewModel.telemetryEvents.collectAsState()
    val lastLatency by viewModel.lastInputLatencyMs.collectAsState()
    val shizukuStatus by viewModel.shizukuStatus.collectAsState()
    val injectionMode by viewModel.injectionMode.collectAsState()

    var score by remember { mutableIntStateOf(0) }
    var showTelemetryDrawer by remember { mutableStateOf(false) }
    var hitFeedbackText by remember { mutableStateOf("") }

    val targets = remember {
        mutableStateListOf(
            HitTarget(1, 0.35f, 0.40f),
            HitTarget(2, 0.50f, 0.32f),
            HitTarget(3, 0.70f, 0.45f)
        )
    }

    val focusRequester = remember { FocusRequester() }

    // Pointer capture management on View
    LaunchedEffect(isPointerCaptured) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (isPointerCaptured) {
                view.requestPointerCapture()
            } else {
                view.releasePointerCapture()
            }
        }
    }

    // Auto-focus to receive physical hardware keys
    LaunchedEffect(Unit) {
        delay(150)
        focusRequester.requestFocus()
    }

    // Check hit on targets when firing
    LaunchedEffect(isFiring) {
        if (isFiring) {
            val cX = crosshairPos.x
            val cY = crosshairPos.y
            val hitIndex = targets.indexOfFirst {
                kotlin.math.abs(it.xRatio - cX) < 0.08f && kotlin.math.abs(it.yRatio - cY) < 0.08f
            }
            if (hitIndex != -1) {
                score += 100
                hitFeedbackText = "ACERTOU ALVO! +100"
                val old = targets[hitIndex]
                targets[hitIndex] = old.copy(isHit = true)
                delay(600)
                targets[hitIndex] = old.copy(
                    xRatio = (0.2f + (Math.random() * 0.6f)).toFloat(),
                    yRatio = (0.25f + (Math.random() * 0.4f)).toFloat(),
                    isHit = false
                )
            }
        }
    }

    // Clear hit text after delay
    LaunchedEffect(hitFeedbackText) {
        if (hitFeedbackText.isNotEmpty()) {
            delay(1200)
            hitFeedbackText = ""
        }
    }

    val zoomScale by animateFloatAsState(
        targetValue = if (isAiming) 1.35f else 1.0f,
        animationSpec = tween(180),
        label = "aim_zoom"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                viewModel.handleKeyEvent(keyEvent.nativeKeyEvent)
                true
            }
            .pointerInput(Unit) {
                // Also allow touch-dragging inside the arena
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    val profile = selectedProfile
                    val sensX = (profile?.mouseSensitivityX ?: 1.0f) * 0.0015f
                    val sensY = (profile?.mouseSensitivityY ?: 1.0f) * 0.0015f
                    val newX = (crosshairPos.x + dragAmount.x * sensX).coerceIn(0.05f, 0.95f)
                    val newY = (crosshairPos.y + dragAmount.y * sensY).coerceIn(0.05f, 0.95f)
                    // Update
                }
            }
    ) {
        // 3D/2D Perspective Grid Canvas with Zoom
        Box(
            modifier = Modifier
                .fillMaxSize()
                .scale(zoomScale)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Horizon and Tactical Ground lines
                val horizonY = h * 0.45f

                // Sky Gradient
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF070B12), Color(0xFF10192A)),
                        startY = 0f,
                        endY = horizonY
                    ),
                    size = androidx.compose.ui.geometry.Size(w, horizonY)
                )

                // Grid Ground
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF131F33), Color(0xFF090E17)),
                        startY = horizonY,
                        endY = h
                    ),
                    topLeft = Offset(0f, horizonY),
                    size = androidx.compose.ui.geometry.Size(w, h - horizonY)
                )

                // Perspective grid lines
                val numGrid = 12
                for (i in 0..numGrid) {
                    val groundX = (w / numGrid) * i
                    drawLine(
                        color = CyberPrimaryCyan.copy(alpha = 0.15f),
                        start = Offset(w / 2f + (joystickOffset.x * 30f), horizonY),
                        end = Offset(groundX + (joystickOffset.x * 80f), h),
                        strokeWidth = 1.5f
                    )
                }

                // Horizontal perspective lines
                for (j in 1..6) {
                    val lineY = horizonY + (h - horizonY) * (j * j / 36f)
                    drawLine(
                        color = CyberPrimaryCyan.copy(alpha = 0.2f),
                        start = Offset(0f, lineY),
                        end = Offset(w, lineY),
                        strokeWidth = 1.5f
                    )
                }
            }

            // Hit Targets in 3D Arena Space
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val cW = constraints.maxWidth.toFloat()
                val cH = constraints.maxHeight.toFloat()

                targets.forEach { target ->
                    val tX = target.xRatio * cW
                    val tY = target.yRatio * cH

                    Box(
                        modifier = Modifier
                            .offset { IntOffset((tX - 24.dp.toPx()).toInt(), (tY - 24.dp.toPx()).toInt()) }
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (target.isHit) CyberGreenActive.copy(alpha = 0.8f) else CyberRedLaser.copy(alpha = 0.4f)
                            )
                            .border(2.dp, if (target.isHit) CyberGreenActive else CyberRedLaser, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (target.isHit) "HIT!" else "ALVO ${target.id}",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Virtual HUD Buttons (WASD, Fire, Aim, Reload, Jump, etc.)
        selectedProfile?.let { profile ->
            VirtualHudOverlay(
                mappings = profile.mappings,
                isEditMode = false,
                activeKeys = activeKeys,
                isFiring = isFiring,
                isAiming = isAiming,
                joystickOffset = joystickOffset
            )
        }

        // Live Crosshair Reticle moving with mouse
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val cW = constraints.maxWidth.toFloat()
            val cH = constraints.maxHeight.toFloat()
            val reticleX = crosshairPos.x * cW
            val reticleY = crosshairPos.y * cH
            val reticleSize = selectedProfile?.crosshairSizeDp ?: 26

            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            (reticleX - (reticleSize.dp.toPx() / 2f)).toInt(),
                            (reticleY - (reticleSize.dp.toPx() / 2f)).toInt()
                        )
                    }
            ) {
                selectedProfile?.let { profile ->
                    CrosshairCanvas(
                        style = profile.crosshairStyle,
                        colorHex = profile.crosshairColorHex,
                        sizeDp = profile.crosshairSizeDp,
                        isFiring = isFiring,
                        isAiming = isAiming
                    )
                }

                // Muzzle Flash Spark Effect when firing
                if (isFiring) {
                    Box(
                        modifier = Modifier
                            .size((reticleSize * 1.6f).dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(CyberAccentAmber.copy(alpha = 0.8f), Color.Transparent)
                                )
                            )
                    )
                }
            }
        }

        // Hit Feedback Banner
        AnimatedVisibility(
            visible = hitFeedbackText.isNotEmpty(),
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-60).dp)
        ) {
            Surface(
                color = CyberDarkBg.copy(alpha = 0.85f),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(2.dp, CyberGreenActive)
            ) {
                Text(
                    text = hitFeedbackText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = CyberGreenActive,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        // Top Control Overlay Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            color = CyberSurface.copy(alpha = 0.85f),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = CyberPrimaryCyan)
                    }
                    Column {
                        Text(
                            text = "ARENA DE TESTE INTERATIVA",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = CyberPrimaryCyan
                        )
                        Text(
                            text = "Placar: $score PTS • Latência: ${lastLatency}ms",
                            fontSize = 11.sp,
                            color = CyberTextSecondary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Pointer Lock Toggle Button
                    Button(
                        onClick = {
                            viewModel.setPointerCaptured(!isPointerCaptured)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPointerCaptured) CyberGreenActive else CyberSurfaceHighlight
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_toggle_mouse_lock")
                    ) {
                        Icon(
                            imageVector = if (isPointerCaptured) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = null,
                            tint = if (isPointerCaptured) CyberDarkBg else CyberTextPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isPointerCaptured) "MOUSE PRESO (Trava ~)" else "TRAVAR MOUSE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPointerCaptured) CyberDarkBg else CyberTextPrimary
                        )
                    }

                    // Telemetry toggle
                    IconButton(onClick = { showTelemetryDrawer = !showTelemetryDrawer }) {
                        Icon(Icons.Default.Bolt, contentDescription = "Logs de Entrada", tint = CyberPrimaryCyan)
                    }
                }
            }
        }

        // Bottom In-Game Telemetry & Guide Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            color = CyberSurface.copy(alpha = 0.90f),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Key guide
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = CyberSurfaceHighlight, shape = RoundedCornerShape(4.dp)) {
                            Text("WASD", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CyberPrimaryCyan, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Andar", fontSize = 11.sp, color = CyberTextSecondary)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = CyberSurfaceHighlight, shape = RoundedCornerShape(4.dp)) {
                            Text("L-CLICK", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CyberRedLaser, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Atirar", fontSize = 11.sp, color = CyberTextSecondary)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = CyberSurfaceHighlight, shape = RoundedCornerShape(4.dp)) {
                            Text("R-CLICK", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CyberAccentAmber, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mirar (ADS)", fontSize = 11.sp, color = CyberTextSecondary)
                    }
                }

                // Injected via Shizuku/Accessibility badge
                Surface(
                    color = CyberSurfaceVariant,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) "MOTOR: SHIZUKU ADB" else "MOTOR: ACESSIBILIDADE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) CyberGreenActive else CyberAccentAmber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Live Telemetry Event Log Drawer
        AnimatedVisibility(
            visible = showTelemetryDrawer,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(280.dp)
                .fillMaxSize()
                .padding(top = 56.dp, bottom = 48.dp)
        ) {
            Surface(
                color = CyberSurface.copy(alpha = 0.96f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TELEMETRIA DE ENTRADA",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberPrimaryCyan
                        )
                        IconButton(onClick = { showTelemetryDrawer = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Fechar", tint = CyberTextMuted, modifier = Modifier.size(18.dp))
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(telemetryList) { item ->
                            Surface(
                                color = CyberSurfaceVariant,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(item.description, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = CyberTextPrimary)
                                        Text(item.source, fontSize = 9.sp, color = CyberTextMuted)
                                    }
                                    Text(
                                        text = if (item.isDown) "ATIVO" else "SOLTO",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (item.isDown) CyberGreenActive else CyberTextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
