package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Cyber Dark Palette
val CyberDarkBg = Color(0xFF090D14)
val CyberSurface = Color(0xFF101724)
val CyberSurfaceVariant = Color(0xFF182234)
val CyberSurfaceHighlight = Color(0xFF223046)

// Neon Esports Accents
val CyberPrimaryCyan = Color(0xFF00F2FE)
val CyberPrimaryCyanDim = Color(0xFF008D94)
val CyberAccentAmber = Color(0xFFFF9500)
val CyberAccentOrange = Color(0xFFFF5722)
val CyberAccentPurple = Color(0xFF9D4EDD)
val CyberGreenActive = Color(0xFF00E676)
val CyberRedLaser = Color(0xFFFF2A55)

// Typography & Borders
val CyberTextPrimary = Color(0xFFF1F5F9)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberTextMuted = Color(0xFF64748B)
val CyberBorder = Color(0xFF26354A)
val CyberBorderActive = Color(0xFF00F2FE)
