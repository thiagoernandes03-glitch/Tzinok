package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.ShizukuStatus
import com.example.ui.theme.CyberAccentAmber
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberPrimaryCyan
import com.example.ui.theme.CyberRedLaser
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceHighlight
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.viewmodel.KeyMapperViewModel

@Composable
fun ActivationGuideScreen(
    viewModel: KeyMapperViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val shizukuStatus by viewModel.shizukuStatus.collectAsState()
    val isAccessibilityActive by viewModel.isAccessibilityActive.collectAsState()
    val isOverlayGranted by viewModel.isOverlayGranted.collectAsState()
    val lastAdbOutput by viewModel.lastAdbOutput.collectAsState()

    var copiedText by remember { mutableStateOf(false) }

    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val isBatteryIgnored = powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = CyberPrimaryCyan)
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "ATIVAÇÃO & PERMISSÕES",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = CyberPrimaryCyan
                    )
                    Text(
                        text = "Configuração do Shizuku e Permissões Avançadas",
                        fontSize = 11.sp,
                        color = CyberTextSecondary
                    )
                }
            }
        }

        // Shizuku Super Activation Hero Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("shizuku_hero_card"),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) CyberGreenActive else CyberAccentAmber
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) CyberGreenActive else CyberAccentAmber,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ESTADO DO SHIZUKU",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = CyberTextPrimary
                            )
                        }

                        Surface(
                            color = when (shizukuStatus) {
                                ShizukuStatus.AUTHORIZED_AND_READY -> CyberGreenActive.copy(alpha = 0.2f)
                                ShizukuStatus.WAITING_PERMISSION -> CyberAccentAmber.copy(alpha = 0.2f)
                                ShizukuStatus.NOT_INSTALLED_OR_STOPPED -> CyberRedLaser.copy(alpha = 0.2f)
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                when (shizukuStatus) {
                                    ShizukuStatus.AUTHORIZED_AND_READY -> CyberGreenActive
                                    ShizukuStatus.WAITING_PERMISSION -> CyberAccentAmber
                                    ShizukuStatus.NOT_INSTALLED_OR_STOPPED -> CyberRedLaser
                                }
                            )
                        ) {
                            Text(
                                text = when (shizukuStatus) {
                                    ShizukuStatus.AUTHORIZED_AND_READY -> "AUTORIZADO (ATIVO)"
                                    ShizukuStatus.WAITING_PERMISSION -> "AGUARDANDO PERMISSÃO"
                                    ShizukuStatus.NOT_INSTALLED_OR_STOPPED -> "INATIVO / DESLIGADO"
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (shizukuStatus) {
                                    ShizukuStatus.AUTHORIZED_AND_READY -> CyberGreenActive
                                    ShizukuStatus.WAITING_PERMISSION -> CyberAccentAmber
                                    ShizukuStatus.NOT_INSTALLED_OR_STOPPED -> CyberRedLaser
                                },
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "O Shizuku permite ao KeyMapper Pro executar chamadas do sistema Android e injeções de toque via ADB de alta velocidade (~1ms de latência) sem a necessidade de computador ou root permanente.",
                        fontSize = 12.sp,
                        color = CyberTextSecondary,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (shizukuStatus == ShizukuStatus.WAITING_PERMISSION) {
                            Button(
                                onClick = { viewModel.requestShizukuPermission() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberAccentAmber),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Autorizar no Shizuku", fontWeight = FontWeight.Bold, color = CyberDarkBg, fontSize = 12.sp)
                            }
                        } else if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) {
                            Button(
                                onClick = { viewModel.grantAllPermissionsViaShizuku() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimaryCyan),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = CyberDarkBg, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Conceder Tudo via Shizuku (1-Clique)", fontWeight = FontWeight.Black, color = CyberDarkBg, fontSize = 11.sp)
                            }
                        }

                        Button(
                            onClick = { viewModel.refreshShizukuStatus() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceHighlight),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Verificar", fontSize = 11.sp, color = CyberTextPrimary)
                        }
                    }

                    if (lastAdbOutput.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Log ADB: $lastAdbOutput",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = CyberGreenActive
                        )
                    }
                }
            }
        }

        // Permissions Checklist Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "CHECKLIST DE PERMISSÕES DO ANDROID",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextMuted,
                        letterSpacing = 1.sp
                    )

                    // 1. Sobreposição de Tela (SYSTEM_ALERT_WINDOW)
                    PermissionCheckRow(
                        title = "Sobreposição de Tela (HUD Flutuante)",
                        description = "Necessário para desenhar os botões mapeados e a mira sobre os jogos.",
                        isGranted = isOverlayGranted,
                        icon = Icons.Default.Layers,
                        onOpenSettings = {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        },
                        onGrantViaShizuku = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) {
                            {
                                viewModel.shizukuManager.grantOverlayPermissionViaAdb()
                                viewModel.checkOverlayPermission()
                            }
                        } else null
                    )

                    // 2. Serviço de Acessibilidade
                    PermissionCheckRow(
                        title = "Serviço de Acessibilidade (Toque)",
                        description = "Permite enviar toques e deslizes na tela simulando os botões.",
                        isGranted = isAccessibilityActive,
                        icon = Icons.Default.TouchApp,
                        onOpenSettings = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            context.startActivity(intent)
                        },
                        onGrantViaShizuku = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) {
                            { viewModel.shizukuManager.grantAccessibilityServiceViaAdb() }
                        } else null
                    )

                    // 3. Economia de Bateria
                    PermissionCheckRow(
                        title = "Otimização de Bateria (Segundo Plano)",
                        description = "Impede o sistema de encerrar o mapeador durante a partida.",
                        isGranted = isBatteryIgnored,
                        icon = Icons.Default.BatteryChargingFull,
                        onOpenSettings = {
                            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                            context.startActivity(intent)
                        },
                        onGrantViaShizuku = if (shizukuStatus == ShizukuStatus.AUTHORIZED_AND_READY) {
                            { viewModel.shizukuManager.grantBatteryOptimizationViaAdb() }
                        } else null
                    )
                }
            }
        }

        // Wireless Debugging & Shizuku Setup Guide
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "COMO ATIVAR O SHIZUKU NO SEU APARELHO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextMuted,
                        letterSpacing = 1.sp
                    )

                    SetupStepItem(
                        step = "1",
                        title = "Instalar o aplicativo Shizuku",
                        desc = "Baixe o Shizuku gratuito na Google Play Store ou GitHub."
                    )

                    SetupStepItem(
                        step = "2",
                        title = "Ativar Depuração por Wi-Fi (Android 11+)",
                        desc = "Vá em Configurações > Opções do Desenvolvedor > Depuração por Wi-Fi e ative."
                    )

                    SetupStepItem(
                        step = "3",
                        title = "Emparelhar no Shizuku",
                        desc = "Abra o Shizuku, toque em 'Emparelhar' e insira o código de 6 dígitos da tela de depuração."
                    )

                    SetupStepItem(
                        step = "4",
                        title = "Iniciar Shizuku e retornar aqui",
                        desc = "Toque em 'Iniciar'. Ao voltar ao KeyMapper Pro, a autorização será detectada instantaneamente!"
                    )
                }
            }
        }

        // Terminal ADB Script Snippet
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Comando de Ativação via PC / Termux (Opcional)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary
                        )

                        IconButton(
                            onClick = {
                                clipboard.setText(AnnotatedString("adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh"))
                                copiedText = true
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copiar", tint = CyberPrimaryCyan, modifier = Modifier.size(18.dp))
                        }
                    }

                    Surface(
                        color = CyberDarkBg,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = CyberPrimaryCyan,
                            modifier = Modifier.padding(10.dp)
                        )
                    }

                    if (copiedText) {
                        Text(
                            text = "Comando copiado para a área de transferência!",
                            fontSize = 10.sp,
                            color = CyberGreenActive,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PermissionCheckRow(
    title: String,
    description: String,
    isGranted: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onOpenSettings: () -> Unit,
    onGrantViaShizuku: (() -> Unit)? = null
) {
    Surface(
        color = CyberSurfaceVariant,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isGranted) CyberGreenActive.copy(alpha = 0.5f) else CyberBorder
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isGranted) CyberGreenActive else CyberAccentAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary
                    )
                }

                Surface(
                    color = if (isGranted) CyberGreenActive.copy(alpha = 0.2f) else CyberRedLaser.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (isGranted) "CONCEDIDA" else "PENDENTE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isGranted) CyberGreenActive else CyberRedLaser,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = description,
                fontSize = 11.sp,
                color = CyberTextSecondary,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onOpenSettings,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceHighlight),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Configurações", fontSize = 11.sp, color = CyberTextPrimary)
                }

                if (onGrantViaShizuku != null && !isGranted) {
                    Button(
                        onClick = onGrantViaShizuku,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPrimaryCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Forçar via Shizuku", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberDarkBg)
                    }
                }
            }
        }
    }
}

@Composable
fun SetupStepItem(step: String, title: String, desc: String) {
    Row(verticalAlignment = Alignment.Top) {
        Surface(
            color = CyberSurfaceHighlight,
            shape = CircleShape,
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimaryCyan),
            modifier = Modifier.size(22.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(step, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberPrimaryCyan)
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
            Text(desc, fontSize = 11.sp, color = CyberTextSecondary)
        }
    }
}
