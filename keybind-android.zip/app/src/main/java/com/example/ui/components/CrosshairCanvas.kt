package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun CrosshairCanvas(
    style: String,
    colorHex: String,
    sizeDp: Int,
    modifier: Modifier = Modifier,
    isFiring: Boolean = false,
    isAiming: Boolean = false
) {
    val reticleColor = try {
        Color(android.graphics.Color.parseColor(colorHex))
    } catch (e: Exception) {
        Color(0xFF00F2FE)
    }

    val displayColor = if (isFiring) Color(0xFFFF2A55) else reticleColor
    val spread = if (isFiring) 1.5f else if (isAiming) 0.6f else 1.0f

    Canvas(modifier = modifier.size(sizeDp.dp)) {
        val centerX = size.width / 2f
        val centerY = size.height / 2f
        val radius = (size.minDimension / 2f) * spread
        val strokeWidth = 2.5f

        when (style.uppercase()) {
            "DOT" -> {
                drawCircle(
                    color = displayColor,
                    radius = (radius * 0.28f).coerceAtLeast(3f),
                    center = Offset(centerX, centerY)
                )
            }
            "CROSS" -> {
                val gap = radius * 0.35f
                val length = radius * 0.85f
                // Top
                drawLine(displayColor, Offset(centerX, centerY - gap), Offset(centerX, centerY - length), strokeWidth, StrokeCap.Round)
                // Bottom
                drawLine(displayColor, Offset(centerX, centerY + gap), Offset(centerX, centerY + length), strokeWidth, StrokeCap.Round)
                // Left
                drawLine(displayColor, Offset(centerX - gap, centerY), Offset(centerX - length, centerY), strokeWidth, StrokeCap.Round)
                // Right
                drawLine(displayColor, Offset(centerX + gap, centerY), Offset(centerX + length, centerY), strokeWidth, StrokeCap.Round)
                // Center dot
                drawCircle(displayColor, radius = 2f, center = Offset(centerX, centerY))
            }
            "CIRCLE" -> {
                drawCircle(
                    color = displayColor,
                    radius = radius * 0.7f,
                    center = Offset(centerX, centerY),
                    style = Stroke(width = strokeWidth)
                )
                drawCircle(displayColor, radius = 3f, center = Offset(centerX, centerY))
            }
            "TACTICAL" -> {
                val gap = radius * 0.25f
                val length = radius * 0.75f
                // Cross lines
                drawLine(displayColor, Offset(centerX, centerY - gap), Offset(centerX, centerY - length), strokeWidth, StrokeCap.Round)
                drawLine(displayColor, Offset(centerX, centerY + gap), Offset(centerX, centerY + length), strokeWidth, StrokeCap.Round)
                drawLine(displayColor, Offset(centerX - gap, centerY), Offset(centerX - length, centerY), strokeWidth, StrokeCap.Round)
                drawLine(displayColor, Offset(centerX + gap, centerY), Offset(centerX + length, centerY), strokeWidth, StrokeCap.Round)

                // Corner tactical brackets
                val cornerDist = radius * 0.85f
                val bracketSize = radius * 0.3f
                // Top-Left
                drawLine(displayColor.copy(alpha = 0.7f), Offset(centerX - cornerDist, centerY - cornerDist), Offset(centerX - cornerDist + bracketSize, centerY - cornerDist), strokeWidth)
                drawLine(displayColor.copy(alpha = 0.7f), Offset(centerX - cornerDist, centerY - cornerDist), Offset(centerX - cornerDist, centerY - cornerDist + bracketSize), strokeWidth)

                // Top-Right
                drawLine(displayColor.copy(alpha = 0.7f), Offset(centerX + cornerDist, centerY - cornerDist), Offset(centerX + cornerDist - bracketSize, centerY - cornerDist), strokeWidth)
                drawLine(displayColor.copy(alpha = 0.7f), Offset(centerX + cornerDist, centerY - cornerDist), Offset(centerX + cornerDist, centerY - cornerDist + bracketSize), strokeWidth)

                // Center precision dot
                drawCircle(displayColor, radius = 2.5f, center = Offset(centerX, centerY))
            }
            "NONE" -> {
                // Invisible
            }
            else -> {
                // Default Cross
                drawCircle(displayColor, radius = 4f, center = Offset(centerX, centerY))
            }
        }
    }
}
