package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val TacticalGamerColorScheme = darkColorScheme(
    primary = CyberPrimaryCyan,
    onPrimary = CyberDarkBg,
    primaryContainer = CyberSurfaceHighlight,
    onPrimaryContainer = CyberPrimaryCyan,
    secondary = CyberAccentAmber,
    onSecondary = CyberDarkBg,
    secondaryContainer = CyberSurfaceVariant,
    onSecondaryContainer = CyberAccentAmber,
    tertiary = CyberAccentPurple,
    onTertiary = CyberDarkBg,
    background = CyberDarkBg,
    onBackground = CyberTextPrimary,
    surface = CyberSurface,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurfaceVariant,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberBorder,
    error = CyberRedLaser,
    onError = CyberTextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to gamer dark theme
    dynamicColor: Boolean = false, // Keep tactical cyan/amber branding
    content: @Composable () -> Unit
) {
    val colorScheme = TacticalGamerColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = CyberDarkBg.toArgb()
                window.navigationBarColor = CyberDarkBg.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
