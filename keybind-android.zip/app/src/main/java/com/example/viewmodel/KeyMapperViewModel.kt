package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.compose.ui.geometry.Offset
import com.example.service.FloatingHudOverlayService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.DefaultProfiles
import com.example.data.GameProfileRepository
import com.example.hardware.InputDeviceDetector
import com.example.model.GameProfile
import com.example.model.HardwareDeviceItem
import com.example.model.InputTelemetryEvent
import com.example.model.KeyMappingItem
import com.example.model.MappingType
import com.example.service.KeyMapperAccessibilityService
import com.example.service.ShizukuManager
import com.example.service.ShizukuStatus
import com.example.service.TouchInjectionMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class KeyMapperViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameProfileRepository
    private val detector: InputDeviceDetector
    val shizukuManager = ShizukuManager(application)

    val profiles: StateFlow<List<GameProfile>>
    private val _selectedProfile = MutableStateFlow<GameProfile?>(null)
    val selectedProfile: StateFlow<GameProfile?> = _selectedProfile.asStateFlow()

    // Hardware devices
    val connectedKeyboards: StateFlow<List<HardwareDeviceItem>>
    val connectedMice: StateFlow<List<HardwareDeviceItem>>
    val hasHardwareKeyboard: StateFlow<Boolean>
    val hasHardwareMouse: StateFlow<Boolean>

    // Shizuku & Injeção
    val shizukuStatus: StateFlow<ShizukuStatus> = shizukuManager.status
    val injectionMode: StateFlow<TouchInjectionMode> = shizukuManager.injectionMode
    val lastAdbOutput: StateFlow<String> = shizukuManager.lastAdbOutput

    // Permissions & Services
    val isAccessibilityActive: StateFlow<Boolean> = KeyMapperAccessibilityService.isActive
    private val _isOverlayGranted = MutableStateFlow(false)
    val isOverlayGranted: StateFlow<Boolean> = _isOverlayGranted.asStateFlow()

    // Interactive Test Arena State
    private val _isPointerCaptured = MutableStateFlow(false)
    val isPointerCaptured: StateFlow<Boolean> = _isPointerCaptured.asStateFlow()

    private val _crosshairPosition = MutableStateFlow(Offset(0.5f, 0.5f))
    val crosshairPosition: StateFlow<Offset> = _crosshairPosition.asStateFlow()

    private val _joystickOffset = MutableStateFlow(Offset(0f, 0f))
    val joystickOffset: StateFlow<Offset> = _joystickOffset.asStateFlow()

    private val _activeKeysDown = MutableStateFlow<Set<Int>>(emptySet())
    val activeKeysDown: StateFlow<Set<Int>> = _activeKeysDown.asStateFlow()

    private val _isFiring = MutableStateFlow(false)
    val isFiring: StateFlow<Boolean> = _isFiring.asStateFlow()

    private val _isAiming = MutableStateFlow(false)
    val isAiming: StateFlow<Boolean> = _isAiming.asStateFlow()

    private val _telemetryEvents = MutableStateFlow<List<InputTelemetryEvent>>(emptyList())
    val telemetryEvents: StateFlow<List<InputTelemetryEvent>> = _telemetryEvents.asStateFlow()

    // Hardware Latency Tester
    private val _lastInputLatencyMs = MutableStateFlow(1L)
    val lastInputLatencyMs: StateFlow<Long> = _lastInputLatencyMs.asStateFlow()

    private val _lastPressedKeyInfo = MutableStateFlow("Nenhuma tecla pressionada")
    val lastPressedKeyInfo: StateFlow<String> = _lastPressedKeyInfo.asStateFlow()

    init {
        val db = AppDatabase.getInstance(application)
        repository = GameProfileRepository(db.gameProfileDao())
        detector = InputDeviceDetector(application)
        detector.startListening()
        shizukuManager.init()

        connectedKeyboards = detector.connectedKeyboards
        connectedMice = detector.connectedMice
        hasHardwareKeyboard = detector.hasHardwareKeyboard
        hasHardwareMouse = detector.hasHardwareMouse

        profiles = repository.allProfiles.stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            DefaultProfiles.getDefaults()
        )

        viewModelScope.launch {
            repository.ensureDefaultsSeeded()
            profiles.collect { list ->
                if (_selectedProfile.value == null && list.isNotEmpty()) {
                    _selectedProfile.value = list.first()
                } else if (_selectedProfile.value != null) {
                    val updated = list.find { it.id == _selectedProfile.value?.id }
                    if (updated != null) {
                        _selectedProfile.value = updated
                    }
                }
            }
        }

        checkOverlayPermission()
    }

    fun requestShizukuPermission() {
        shizukuManager.requestShizukuPermission()
    }

    fun refreshShizukuStatus() {
        shizukuManager.checkStatus()
    }

    fun setInjectionMode(mode: TouchInjectionMode) {
        shizukuManager.setInjectionMode(mode)
    }

    fun grantAllPermissionsViaShizuku() {
        viewModelScope.launch {
            shizukuManager.grantOverlayPermissionViaAdb()
            shizukuManager.grantAccessibilityServiceViaAdb()
            shizukuManager.grantBatteryOptimizationViaAdb()
            checkOverlayPermission()
        }
    }

    fun checkOverlayPermission() {
        val granted = Settings.canDrawOverlays(getApplication())
        _isOverlayGranted.value = granted
    }

    fun launchGameWithOverlay(context: Context, profile: GameProfile) {
        // If overlay permission is not granted, try via Shizuku or open settings
        if (!Settings.canDrawOverlays(context)) {
            if (shizukuManager.isAuthorized()) {
                shizukuManager.grantOverlayPermissionViaAdb()
                checkOverlayPermission()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            }
        }

        // Start overlay HUD service
        val serviceIntent = Intent(context, FloatingHudOverlayService::class.java).apply {
            putExtra("PROFILE_ID", profile.id)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }

        // Launch target game if installed
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(profile.packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        }
    }

    fun stopFloatingOverlay(context: Context) {
        val intent = Intent(context, FloatingHudOverlayService::class.java)
        context.stopService(intent)
    }

    fun selectProfile(profile: GameProfile) {
        _selectedProfile.value = profile
    }

    fun setPointerCaptured(captured: Boolean) {
        _isPointerCaptured.value = captured
    }

    // Touch and Gesture injection via Accessibility
    fun injectTouch(x: Float, y: Float) {
        KeyMapperAccessibilityService.instance?.injectTap(x, y)
    }

    // Process Keyboard Event
    fun handleKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val isDown = event.action == KeyEvent.ACTION_DOWN
        val profile = _selectedProfile.value

        val startNs = SystemClock.elapsedRealtimeNanos()

        // Check if cursor lock key was pressed (e.g. ~ or Grave)
        if (isDown && (keyCode == KeyEvent.KEYCODE_GRAVE || event.displayLabel.toString() == profile?.cursorLockKey)) {
            _isPointerCaptured.value = !_isPointerCaptured.value
            addTelemetry("MOUSE", "Alternou Cursor Lock: ${_isPointerCaptured.value}", keyCode, isDown)
            return true
        }

        val currentKeys = _activeKeysDown.value.toMutableSet()
        if (isDown) {
            currentKeys.add(keyCode)
        } else {
            currentKeys.remove(keyCode)
        }
        _activeKeysDown.value = currentKeys

        // Recalculate virtual WASD joystick based on active keys
        var jX = 0f
        var jY = 0f
        if (currentKeys.contains(KeyEvent.KEYCODE_W)) jY -= 1f
        if (currentKeys.contains(KeyEvent.KEYCODE_S)) jY += 1f
        if (currentKeys.contains(KeyEvent.KEYCODE_A)) jX -= 1f
        if (currentKeys.contains(KeyEvent.KEYCODE_D)) jX += 1f

        val length = kotlin.math.sqrt(jX * jX + jY * jY)
        if (length > 0) {
            val mult = if (currentKeys.contains(KeyEvent.KEYCODE_SHIFT_LEFT)) 1.0f else 0.7f
            _joystickOffset.value = Offset((jX / length) * mult, (jY / length) * mult)
        } else {
            _joystickOffset.value = Offset(0f, 0f)
        }

        val keyName = KeyEvent.keyCodeToString(keyCode).removePrefix("KEYCODE_")
        _lastPressedKeyInfo.value = "Tecla $keyName (Código: $keyCode) [${if (isDown) "DOWN" else "UP"}]"
        addTelemetry("TECLADO", "Tecla $keyName ${if (isDown) "pressionada" else "solta"}", keyCode, isDown)

        val endNs = SystemClock.elapsedRealtimeNanos()
        _lastInputLatencyMs.value = ((endNs - startNs) / 1_000_000).coerceAtLeast(1L)

        // Inject touch via Shizuku ADB or accessibility service if mapped button exists
        if (isDown && profile != null) {
            val matchingMapping = profile.mappings.find { it.keyCode == keyCode }
            if (matchingMapping != null) {
                val displayMetrics = getApplication<Application>().resources.displayMetrics
                val targetX = matchingMapping.posXRatio * displayMetrics.widthPixels
                val targetY = matchingMapping.posYRatio * displayMetrics.heightPixels

                if (shizukuManager.isAuthorized() && injectionMode.value == TouchInjectionMode.SHIZUKU_ADB) {
                    shizukuManager.injectTouchAdb(targetX, targetY)
                } else {
                    KeyMapperAccessibilityService.instance?.injectTap(targetX, targetY)
                }
            }
        }

        return false
    }

    // Process Mouse Motion Event
    fun handleMotionEvent(event: MotionEvent): Boolean {
        val startNs = SystemClock.elapsedRealtimeNanos()
        val profile = _selectedProfile.value

        when (event.actionMasked) {
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> {
                // Delta movement for camera look
                val deltaX = event.getAxisValue(MotionEvent.AXIS_RELATIVE_X)
                val deltaY = event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y)

                if (deltaX != 0f || deltaY != 0f) {
                    val sensX = (profile?.mouseSensitivityX ?: 1.0f) * 0.002f
                    val sensY = (profile?.mouseSensitivityY ?: 1.0f) * 0.002f
                    val adsModifier = if (_isAiming.value) (profile?.adsSensitivityModifier ?: 0.75f) else 1.0f

                    val current = _crosshairPosition.value
                    val antiRecoil = if (_isFiring.value) (profile?.antiRecoilPullDown ?: 0f) * 0.003f else 0f

                    val newX = (current.x + deltaX * sensX * adsModifier).coerceIn(0.05f, 0.95f)
                    val newY = (current.y + deltaY * sensY * adsModifier + antiRecoil).coerceIn(0.05f, 0.95f)
                    _crosshairPosition.value = Offset(newX, newY)

                    addTelemetry("MOUSE", "Movimento Delta: (${deltaX.toInt()}, ${deltaY.toInt()})", 0, true)
                }
            }
            MotionEvent.ACTION_BUTTON_PRESS -> {
                when (event.actionButton) {
                    MotionEvent.BUTTON_PRIMARY -> {
                        _isFiring.value = true
                        addTelemetry("MOUSE", "Disparo Primário (Left Click)", KeyMappingItem.KEY_CODE_MOUSE_LEFT, true)
                        triggerMappedMouseAction(KeyMappingItem.KEY_CODE_MOUSE_LEFT)
                    }
                    MotionEvent.BUTTON_SECONDARY -> {
                        _isAiming.value = !_isAiming.value
                        addTelemetry("MOUSE", "Mira Óptica ADS (Right Click): ${_isAiming.value}", KeyMappingItem.KEY_CODE_MOUSE_RIGHT, true)
                        triggerMappedMouseAction(KeyMappingItem.KEY_CODE_MOUSE_RIGHT)
                    }
                    MotionEvent.BUTTON_TERTIARY -> {
                        addTelemetry("MOUSE", "Botão Central (Scroll Click)", KeyMappingItem.KEY_CODE_MOUSE_MIDDLE, true)
                    }
                }
            }
            MotionEvent.ACTION_BUTTON_RELEASE -> {
                when (event.actionButton) {
                    MotionEvent.BUTTON_PRIMARY -> {
                        _isFiring.value = false
                        addTelemetry("MOUSE", "Disparo Solto", KeyMappingItem.KEY_CODE_MOUSE_LEFT, false)
                    }
                }
            }
            MotionEvent.ACTION_SCROLL -> {
                val scroll = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
                if (scroll > 0) {
                    addTelemetry("MOUSE", "Scroll Para Cima (Arma Anterior)", KeyMappingItem.KEY_CODE_MOUSE_WHEEL_UP, true)
                } else if (scroll < 0) {
                    addTelemetry("MOUSE", "Scroll Para Baixo (Próxima Arma)", KeyMappingItem.KEY_CODE_MOUSE_WHEEL_DOWN, true)
                }
            }
        }

        val endNs = SystemClock.elapsedRealtimeNanos()
        _lastInputLatencyMs.value = ((endNs - startNs) / 1_000_000).coerceAtLeast(1L)
        return true
    }

    private fun triggerMappedMouseAction(mouseCode: Int) {
        val profile = _selectedProfile.value ?: return
        val mapping = profile.mappings.find { it.keyCode == mouseCode } ?: return
        val displayMetrics = getApplication<Application>().resources.displayMetrics
        val targetX = mapping.posXRatio * displayMetrics.widthPixels
        val targetY = mapping.posYRatio * displayMetrics.heightPixels

        if (shizukuManager.isAuthorized() && injectionMode.value == TouchInjectionMode.SHIZUKU_ADB) {
            shizukuManager.injectTouchAdb(targetX, targetY)
        } else {
            KeyMapperAccessibilityService.instance?.injectTap(targetX, targetY)
        }
    }

    private fun addTelemetry(source: String, desc: String, keyCode: Int, isDown: Boolean) {
        val list = _telemetryEvents.value.toMutableList()
        list.add(0, InputTelemetryEvent(source = source, description = desc, keyCode = keyCode, isDown = isDown))
        if (list.size > 25) {
            _telemetryEvents.value = list.subList(0, 25)
        } else {
            _telemetryEvents.value = list
        }
    }

    // Mapping Editor Actions
    fun updateMappingPosition(mappingId: String, newXRatio: Float, newYRatio: Float) {
        val current = _selectedProfile.value ?: return
        val updatedMappings = current.mappings.map { item ->
            if (item.id == mappingId) {
                item.copy(
                    posXRatio = newXRatio.coerceIn(0.02f, 0.98f),
                    posYRatio = newYRatio.coerceIn(0.02f, 0.98f)
                )
            } else item
        }
        saveCurrentProfile(current.copy(mappings = updatedMappings))
    }

    fun updateMappingKey(mappingId: String, newKeyCode: Int, newDisplayKey: String) {
        val current = _selectedProfile.value ?: return
        val updatedMappings = current.mappings.map { item ->
            if (item.id == mappingId) {
                item.copy(keyCode = newKeyCode, displayKey = newDisplayKey)
            } else item
        }
        saveCurrentProfile(current.copy(mappings = updatedMappings))
    }

    fun updateMappingRadius(mappingId: String, radiusRatio: Float) {
        val current = _selectedProfile.value ?: return
        val updatedMappings = current.mappings.map { item ->
            if (item.id == mappingId) {
                item.copy(radiusRatio = radiusRatio.coerceIn(0.03f, 0.25f))
            } else item
        }
        saveCurrentProfile(current.copy(mappings = updatedMappings))
    }

    fun addMapping(
        label: String,
        type: MappingType,
        keyCode: Int,
        displayKey: String,
        posXRatio: Float = 0.5f,
        posYRatio: Float = 0.5f
    ) {
        val current = _selectedProfile.value ?: return
        val newItem = KeyMappingItem(
            id = "map_${UUID.randomUUID().toString().take(8)}",
            label = label,
            type = type,
            keyCode = keyCode,
            displayKey = displayKey,
            posXRatio = posXRatio,
            posYRatio = posYRatio
        )
        saveCurrentProfile(current.copy(mappings = current.mappings + newItem))
    }

    fun deleteMapping(mappingId: String) {
        val current = _selectedProfile.value ?: return
        val updatedMappings = current.mappings.filterNot { it.id == mappingId }
        saveCurrentProfile(current.copy(mappings = updatedMappings))
    }

    // Sensitivity & Profile Tuning
    fun updateSensitivity(sensX: Float, sensY: Float, adsMod: Float, antiRecoil: Float) {
        val current = _selectedProfile.value ?: return
        saveCurrentProfile(
            current.copy(
                mouseSensitivityX = sensX,
                mouseSensitivityY = sensY,
                adsSensitivityModifier = adsMod,
                antiRecoilPullDown = antiRecoil
            )
        )
    }

    fun updateCrosshair(style: String, colorHex: String, sizeDp: Int) {
        val current = _selectedProfile.value ?: return
        saveCurrentProfile(
            current.copy(
                crosshairStyle = style,
                crosshairColorHex = colorHex,
                crosshairSizeDp = sizeDp
            )
        )
    }

    fun toggleFavoriteProfile(profile: GameProfile) {
        viewModelScope.launch {
            val updated = profile.copy(isFavorite = !profile.isFavorite)
            repository.saveProfile(updated)
            if (_selectedProfile.value?.id == profile.id) {
                _selectedProfile.value = updated
            }
        }
    }

    fun createNewProfile(name: String, genre: String, packageName: String) {
        val newProfile = GameProfile(
            id = "profile_${UUID.randomUUID().toString().take(8)}",
            name = name.ifBlank { "Novo Jogo" },
            genre = genre.ifBlank { "Ação" },
            packageName = packageName.ifBlank { "com.game" },
            mappings = DefaultProfiles.createCustomProfile().mappings
        )
        viewModelScope.launch {
            repository.saveProfile(newProfile)
            _selectedProfile.value = newProfile
        }
    }

    fun deleteProfile(profileId: String) {
        viewModelScope.launch {
            repository.deleteProfile(profileId)
        }
    }

    fun resetProfileToDefault(profileId: String) {
        viewModelScope.launch {
            repository.resetProfileToDefault(profileId)
            val updated = repository.getProfileById(profileId)
            if (updated != null) {
                _selectedProfile.value = updated
            }
        }
    }

    private fun saveCurrentProfile(profile: GameProfile) {
        _selectedProfile.value = profile
        viewModelScope.launch {
            repository.saveProfile(profile)
        }
    }

    override fun onCleared() {
        super.onCleared()
        detector.stopListening()
        shizukuManager.destroy()
    }
}
