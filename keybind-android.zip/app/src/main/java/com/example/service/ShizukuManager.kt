package com.example.service

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

enum class ShizukuStatus {
    NOT_INSTALLED_OR_STOPPED, // Shizuku não está rodando
    WAITING_PERMISSION,       // Shizuku está ativo, mas precisa de permissão do usuário
    AUTHORIZED_AND_READY      // Shizuku 100% ativo e pronto para injeção ADB rápida
}

enum class TouchInjectionMode {
    SHIZUKU_ADB,              // Injeção direta ADB via Shizuku (Zero lag, funciona em todos os jogos)
    ACCESSIBILITY_SERVICE,    // Injeção nativa via Serviço de Acessibilidade (Padrão Android)
    SIMULATION_INTERNAL       // Simulação interna no Arena de Teste do app
}

class ShizukuManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO)

    private val _status = MutableStateFlow(ShizukuStatus.NOT_INSTALLED_OR_STOPPED)
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private val _injectionMode = MutableStateFlow(TouchInjectionMode.ACCESSIBILITY_SERVICE)
    val injectionMode: StateFlow<TouchInjectionMode> = _injectionMode.asStateFlow()

    private val _lastAdbOutput = MutableStateFlow("")
    val lastAdbOutput: StateFlow<String> = _lastAdbOutput.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        checkStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _status.value = ShizukuStatus.NOT_INSTALLED_OR_STOPPED
        if (_injectionMode.value == TouchInjectionMode.SHIZUKU_ADB) {
            _injectionMode.value = TouchInjectionMode.ACCESSIBILITY_SERVICE
        }
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            _status.value = ShizukuStatus.AUTHORIZED_AND_READY
            _injectionMode.value = TouchInjectionMode.SHIZUKU_ADB
            Log.d(TAG, "Permissão Shizuku concedida com sucesso!")
        } else {
            _status.value = ShizukuStatus.WAITING_PERMISSION
            Log.w(TAG, "Permissão Shizuku negada.")
        }
    }

    fun init() {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            checkStatus()
        } catch (e: Throwable) {
            Log.e(TAG, "Erro ao inicializar Shizuku: ${e.message}")
            _status.value = ShizukuStatus.NOT_INSTALLED_OR_STOPPED
        }
    }

    fun destroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            Log.e(TAG, "Erro ao encerrar Shizuku: ${e.message}")
        }
    }

    fun checkStatus() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    _status.value = ShizukuStatus.AUTHORIZED_AND_READY
                    _injectionMode.value = TouchInjectionMode.SHIZUKU_ADB
                } else {
                    _status.value = ShizukuStatus.WAITING_PERMISSION
                }
            } else {
                _status.value = ShizukuStatus.NOT_INSTALLED_OR_STOPPED
            }
        } catch (e: Throwable) {
            _status.value = ShizukuStatus.NOT_INSTALLED_OR_STOPPED
        }
    }

    fun requestShizukuPermission(requestCode: Int = 1001) {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(requestCode)
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Falha ao solicitar permissão Shizuku: ${e.message}")
        }
    }

    fun setInjectionMode(mode: TouchInjectionMode) {
        _injectionMode.value = mode
    }

    /**
     * Executa comandos shell com permissão ADB/Rootless através do Shizuku
     */
    suspend fun executeCommand(command: String): String = withContext(Dispatchers.IO) {
        if (!isAuthorized()) {
            return@withContext "Shizuku não autorizado ou inativo"
        }
        try {
            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }

            val process = newProcessMethod.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line).append("\n")
            }
            process.waitFor()
            val result = output.toString().trim()
            _lastAdbOutput.value = if (result.isEmpty()) "OK ($command)" else result
            return@withContext result
        } catch (e: Throwable) {
            Log.e(TAG, "Erro executando comando Shizuku '$command': ${e.message}")
            return@withContext "Erro: ${e.message}"
        }
    }

    /**
     * Injeta toque rápido via Shizuku ADB: input tap X Y
     */
    fun injectTouchAdb(x: Float, y: Float) {
        if (!isAuthorized()) return
        scope.launch {
            executeCommand("input tap ${x.toInt()} ${y.toInt()}")
        }
    }

    /**
     * Injeta deslize / swipe via Shizuku ADB: input swipe X1 Y1 X2 Y2 [duration]
     */
    fun injectSwipeAdb(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 100) {
        if (!isAuthorized()) return
        scope.launch {
            executeCommand("input swipe ${startX.toInt()} ${startY.toInt()} ${endX.toInt()} ${endY.toInt()} $durationMs")
        }
    }

    /**
     * Injeta tecla via Shizuku ADB: input keyevent KEYCODE
     */
    fun injectKeyEventAdb(keyCode: Int) {
        if (!isAuthorized()) return
        scope.launch {
            executeCommand("input keyevent $keyCode")
        }
    }

    /**
     * Concede automaticamente permissão de sobreposição (SYSTEM_ALERT_WINDOW) via ADB sem precisar ir nas configurações!
     */
    fun grantOverlayPermissionViaAdb() {
        val packageName = context.packageName
        scope.launch {
            executeCommand("appops set $packageName SYSTEM_ALERT_WINDOW allow")
        }
    }

    /**
     * Ativa automaticamente o Serviço de Acessibilidade do KeyMapper via ADB!
     */
    fun grantAccessibilityServiceViaAdb() {
        val serviceComponent = "${context.packageName}/${KeyMapperAccessibilityService::class.java.canonicalName}"
        scope.launch {
            executeCommand("settings put secure enabled_accessibility_services $serviceComponent")
            executeCommand("settings put secure accessibility_enabled 1")
        }
    }

    /**
     * Remove restrições de economia de bateria via ADB
     */
    fun grantBatteryOptimizationViaAdb() {
        val packageName = context.packageName
        scope.launch {
            executeCommand("dumpsys deviceidle whitelist +$packageName")
        }
    }

    fun isAuthorized(): Boolean {
        return _status.value == ShizukuStatus.AUTHORIZED_AND_READY
    }

    companion object {
        private const val TAG = "ShizukuManager"
    }
}
