package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.example.R
import com.example.data.AppDatabase
import com.example.data.GameProfileRepository
import com.example.model.GameProfile
import com.example.model.KeyMappingItem
import com.example.model.MappingType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.UUID

class FloatingHudOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingBubble: FrameLayout? = null
    private var compactToolbar: FrameLayout? = null
    private var overlayButtonsContainer: FrameLayout? = null
    private var inspectorDialogView: FrameLayout? = null

    private val scope = CoroutineScope(Dispatchers.Main)
    private var currentProfile: GameProfile? = null
    private var currentProfileId: String = "profile_free_fire"

    private var isEditModeActive = false
    private var selectedItemForEdit: KeyMappingItem? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        currentProfileId = intent?.getStringExtra("PROFILE_ID") ?: currentProfileId
        loadProfileAndInit(currentProfileId)
        return START_STICKY
    }

    private fun loadProfileAndInit(profileId: String) {
        scope.launch(Dispatchers.IO) {
            val db = AppDatabase.getInstance(applicationContext)
            val repo = GameProfileRepository(db.gameProfileDao())
            val profile = repo.getProfileById(profileId)
            scope.launch(Dispatchers.Main) {
                currentProfile = profile
                createFloatingBubble()
                createOverlayButtonsContainer()
                renderOverlayButtons()
            }
        }
    }

    private fun getOverlayLayoutType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    /**
     * 1. Bolha Flutuante Compacta com Logo Oficial do Itachi
     */
    private fun createFloatingBubble() {
        val wm = windowManager ?: return
        if (floatingBubble != null) return

        val density = resources.displayMetrics.density

        floatingBubble = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#F0090D14"))
                setStroke((2 * density).toInt(), Color.parseColor("#FF00F2FE"))
            }
            val pad = (4 * density).toInt()
            setPadding(pad, pad, pad, pad)

            val logoView = ImageView(context).apply {
                setImageResource(R.drawable.app_logo)
                val iconSize = (36 * density).toInt()
                layoutParams = FrameLayout.LayoutParams(iconSize, iconSize).apply {
                    gravity = Gravity.CENTER
                }
            }
            addView(logoView)
        }

        val bubbleSize = (44 * density).toInt()
        val params = WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            getOverlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * density).toInt()
            y = (130 * density).toInt()
        }

        floatingBubble?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isClick = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) {
                            isClick = false
                        }
                        params.x = initialX + dx
                        params.y = initialY + dy
                        wm.updateViewLayout(floatingBubble, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick) {
                            toggleEditMode()
                        }
                        return true
                    }
                }
                return false
            }
        })

        try {
            wm.addView(floatingBubble, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Alterna Modo Edição (Barra aberta + Botões arrastáveis) e Modo Jogo (100% transparente para toques)
     */
    private fun toggleEditMode() {
        isEditModeActive = !isEditModeActive
        if (isEditModeActive) {
            showCompactToolbar()
            updateOverlayTouchability(true)
            Toast.makeText(this, "Mapeamento Aberto: Arraste ou configure teclas", Toast.LENGTH_SHORT).show()
        } else {
            hideCompactToolbar()
            hideInspectorDialog()
            updateOverlayTouchability(false)
            saveProfileChanges()
            Toast.makeText(this, "Mapeamento Salvo e Ativo!", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * 2. Barra Flutuante Compacta e Simples
     */
    private fun showCompactToolbar() {
        val wm = windowManager ?: return
        if (compactToolbar != null) return

        val density = resources.displayMetrics.density

        val toolbarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14 * density
                setColor(Color.parseColor("#F50D1117"))
                setStroke((1.5f * density).toInt(), Color.parseColor("#FF00F2FE"))
            }
            setPadding((10 * density).toInt(), (6 * density).toInt(), (10 * density).toInt(), (6 * density).toInt())

            // + Tecla
            addView(createCompactPill("+ Tecla", "#FF1E293B", "#FFFFFFFF") {
                val item = addNewButtonMapping("Tecla", MappingType.BUTTON, android.view.KeyEvent.KEYCODE_E, "E", radius = 0.06f)
                openInspectorFor(item)
            })

            // + WASD
            addView(createCompactPill("+ WASD", "#FF0F2B30", "#FF00F2FE") {
                val item = addNewButtonMapping("Analógico", MappingType.DPAD_WASD, android.view.KeyEvent.KEYCODE_W, "WASD", radius = 0.12f)
                openInspectorFor(item)
            })

            // + Vista (Sens X/Y)
            addView(createCompactPill("+ Vista", "#FF2D1A10", "#FFFF5722") {
                val item = addNewButtonMapping("Câmera / Vista", MappingType.MOUSE_LOOK, android.view.KeyEvent.KEYCODE_GRAVE, "MIRA (~)", radius = 0.15f)
                openInspectorFor(item)
            })

            // + Tiro
            addView(createCompactPill("+ Tiro", "#FF2D1219", "#FFFF2A55") {
                addNewButtonMapping("Tiro", MappingType.FIRE_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_LEFT, "L-CLICK", radius = 0.08f)
            })

            // + Mira ADS
            addView(createCompactPill("+ Mira", "#FF2A2210", "#FFFF9500") {
                addNewButtonMapping("Mira ADS", MappingType.AIM_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_RIGHT, "R-CLICK", radius = 0.07f)
            })

            // Salvar
            addView(createCompactPill("✓ Salvar", "#FF00F2FE", "#FF090D14") {
                toggleEditMode()
            })
        }

        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(toolbarLayout)
        }

        compactToolbar = FrameLayout(this).apply {
            addView(scroll)
        }

        val screenWidth = resources.displayMetrics.widthPixels
        val params = WindowManager.LayoutParams(
            (screenWidth * 0.95f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            getOverlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (16 * density).toInt()
        }

        try {
            wm.addView(compactToolbar, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideCompactToolbar() {
        val wm = windowManager ?: return
        compactToolbar?.let {
            try { wm.removeView(it) } catch (e: Exception) {}
            compactToolbar = null
        }
    }

    private fun createCompactPill(label: String, bgHex: String, textHex: String, onClick: () -> Unit): View {
        val density = resources.displayMetrics.density
        return TextView(this).apply {
            text = label
            textSize = 11f
            setTextColor(Color.parseColor(textHex))
            paint.isFakeBoldText = true
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 8 * density
                setColor(Color.parseColor(bgHex))
                setStroke((1 * density).toInt(), Color.parseColor("#44FFFFFF"))
            }
            setPadding((10 * density).toInt(), (6 * density).toInt(), (10 * density).toInt(), (6 * density).toInt())
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = (6 * density).toInt()
            }
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    /**
     * 3. Painel de Ajuste Compacto: Raio / Delay ms / Sensibilidades X & Y (Sem Interferência)
     */
    private fun openInspectorFor(item: KeyMappingItem) {
        selectedItemForEdit = item
        showInspectorDialog()
    }

    private fun showInspectorDialog() {
        val wm = windowManager ?: return
        hideInspectorDialog()

        val item = selectedItemForEdit ?: return
        val profile = currentProfile ?: return
        val density = resources.displayMetrics.density

        val isVista = item.type == MappingType.MOUSE_LOOK
        val isWasd = item.type == MappingType.DPAD_WASD

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14 * density
                setColor(Color.parseColor("#F7090D14"))
                setStroke((1.5f * density).toInt(), if (isVista) Color.parseColor("#FFFF5722") else Color.parseColor("#FF00F2FE"))
            }
            setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (14 * density).toInt())

            // Title
            val titleColor = if (isVista) "#FFFF5722" else "#FF00F2FE"
            addView(TextView(context).apply {
                text = "CONFIGURAÇÃO: ${item.label.uppercase()} [${item.displayKey}]"
                setTextColor(Color.parseColor(titleColor))
                textSize = 12f
                paint.isFakeBoldText = true
            })

            // 1. Raio / Tamanho do Botão (Evita interferência e toque acidental em botões vizinhos)
            val tvRadius = TextView(context).apply {
                text = "Raio / Área de Toque: ${(item.radiusRatio * 100).toInt()}%"
                setTextColor(Color.WHITE)
                textSize = 11f
                setPadding(0, (8 * density).toInt(), 0, 0)
            }
            addView(tvRadius)

            val seekRadius = SeekBar(context).apply {
                max = 20 // 4% .. 24%
                progress = ((item.radiusRatio * 100).toInt() - 4).coerceIn(0, 20)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(p0: SeekBar?, progress: Int, p2: Boolean) {
                        val newRadius = (progress + 4) / 100f
                        updateItemRadius(item.id, newRadius)
                        tvRadius.text = "Raio / Área de Toque: ${(newRadius * 100).toInt()}%"
                    }
                    override fun onStartTrackingTouch(p0: SeekBar?) {}
                    override fun onStopTrackingTouch(p0: SeekBar?) {}
                })
            }
            addView(seekRadius)

            // 2. Delay do Toque em MS (Garante registro correto no jogo sem ghost touches)
            val tvDelay = TextView(context).apply {
                text = "Delay / Duração do Toque: ${item.touchDelayMs}ms"
                setTextColor(Color.WHITE)
                textSize = 11f
                setPadding(0, (6 * density).toInt(), 0, 0)
            }
            addView(tvDelay)

            val seekDelay = SeekBar(context).apply {
                max = 90 // 10ms .. 100ms
                progress = (item.touchDelayMs.toInt() - 10).coerceIn(0, 90)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(p0: SeekBar?, progress: Int, p2: Boolean) {
                        val newDelay = (progress + 10).toLong()
                        updateItemDelay(item.id, newDelay)
                        tvDelay.text = "Delay / Duração do Toque: ${newDelay}ms"
                    }
                    override fun onStartTrackingTouch(p0: SeekBar?) {}
                    override fun onStopTrackingTouch(p0: SeekBar?) {}
                })
            }
            addView(seekDelay)

            // 3. Se for o Botão de Vista: Sensibilidade X e Sensibilidade Y
            if (isVista) {
                // Sensibilidade X
                val tvSensX = TextView(context).apply {
                    text = "Sensibilidade X (Horizontal): ${String.format("%.2f", profile.mouseSensitivityX)}"
                    setTextColor(Color.parseColor("#FFFF5722"))
                    textSize = 11f
                    setPadding(0, (6 * density).toInt(), 0, 0)
                }
                addView(tvSensX)

                val seekSensX = SeekBar(context).apply {
                    max = 300
                    progress = (profile.mouseSensitivityX * 100).toInt().coerceIn(10, 300)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(p0: SeekBar?, progress: Int, p2: Boolean) {
                            val value = progress.coerceAtLeast(10) / 100f
                            currentProfile = currentProfile?.copy(mouseSensitivityX = value)
                            tvSensX.text = "Sensibilidade X (Horizontal): ${String.format("%.2f", value)}"
                        }
                        override fun onStartTrackingTouch(p0: SeekBar?) {}
                        override fun onStopTrackingTouch(p0: SeekBar?) {}
                    })
                }
                addView(seekSensX)

                // Sensibilidade Y
                val tvSensY = TextView(context).apply {
                    text = "Sensibilidade Y (Vertical): ${String.format("%.2f", profile.mouseSensitivityY)}"
                    setTextColor(Color.parseColor("#FFFF5722"))
                    textSize = 11f
                    setPadding(0, (4 * density).toInt(), 0, 0)
                }
                addView(tvSensY)

                val seekSensY = SeekBar(context).apply {
                    max = 300
                    progress = (profile.mouseSensitivityY * 100).toInt().coerceIn(10, 300)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(p0: SeekBar?, progress: Int, p2: Boolean) {
                            val value = progress.coerceAtLeast(10) / 100f
                            currentProfile = currentProfile?.copy(mouseSensitivityY = value)
                            tvSensY.text = "Sensibilidade Y (Vertical): ${String.format("%.2f", value)}"
                        }
                        override fun onStartTrackingTouch(p0: SeekBar?) {}
                        override fun onStopTrackingTouch(p0: SeekBar?) {}
                    })
                }
                addView(seekSensY)
            }

            // Ações: Excluir e Confirmar
            val actionsRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                setPadding(0, (10 * density).toInt(), 0, 0)

                // Excluir
                addView(createCompactPill("Excluir", "#FF331118", "#FFFF2A55") {
                    deleteItem(item.id)
                    hideInspectorDialog()
                })

                // Confirmar
                addView(createCompactPill("Confirmar", "#FF00F2FE", "#FF090D14") {
                    hideInspectorDialog()
                    saveProfileChanges()
                    renderOverlayButtons()
                })
            }
            addView(actionsRow)
        }

        inspectorDialogView = FrameLayout(this).apply {
            addView(content)
        }

        val screenWidth = resources.displayMetrics.widthPixels
        val params = WindowManager.LayoutParams(
            (screenWidth * 0.85f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            getOverlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        try {
            wm.addView(inspectorDialogView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideInspectorDialog() {
        val wm = windowManager ?: return
        inspectorDialogView?.let {
            try { wm.removeView(it) } catch (e: Exception) {}
            inspectorDialogView = null
        }
    }

    private fun updateItemRadius(itemId: String, radius: Float) {
        val profile = currentProfile ?: return
        val updated = profile.mappings.map {
            if (it.id == itemId) it.copy(radiusRatio = radius) else it
        }
        currentProfile = profile.copy(mappings = updated)
        renderOverlayButtons()
    }

    private fun updateItemDelay(itemId: String, delayMs: Long) {
        val profile = currentProfile ?: return
        val updated = profile.mappings.map {
            if (it.id == itemId) it.copy(touchDelayMs = delayMs) else it
        }
        currentProfile = profile.copy(mappings = updated)
    }

    private fun deleteItem(itemId: String) {
        val profile = currentProfile ?: return
        val updated = profile.mappings.filterNot { it.id == itemId }
        currentProfile = profile.copy(mappings = updated)
        renderOverlayButtons()
        Toast.makeText(this, "Botão removido", Toast.LENGTH_SHORT).show()
    }

    /**
     * 4. Renderização dos Botões Mapeados na Tela
     */
    private fun createOverlayButtonsContainer() {
        val wm = windowManager ?: return
        if (overlayButtonsContainer != null) return

        overlayButtonsContainer = FrameLayout(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            getOverlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        try {
            wm.addView(overlayButtonsContainer, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateOverlayTouchability(isInteractive: Boolean) {
        val wm = windowManager ?: return
        val container = overlayButtonsContainer ?: return

        val flags = if (isInteractive) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            getOverlayLayoutType(),
            flags,
            PixelFormat.TRANSLUCENT
        )

        try {
            wm.updateViewLayout(container, params)
            renderOverlayButtons()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun renderOverlayButtons() {
        val container = overlayButtonsContainer ?: return
        container.removeAllViews()

        val profile = currentProfile ?: return
        val metrics = resources.displayMetrics
        val screenWidth = metrics.widthPixels
        val screenHeight = metrics.heightPixels
        val density = metrics.density

        for (item in profile.mappings) {
            val badgeSize = (item.radiusRatio * 2f * screenWidth.coerceAtMost(screenHeight)).toInt().coerceIn(36, 150)

            val isVista = item.type == MappingType.MOUSE_LOOK
            val isWasd = item.type == MappingType.DPAD_WASD
            val isFire = item.type == MappingType.FIRE_BUTTON
            val isAim = item.type == MappingType.AIM_BUTTON

            val buttonView = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    val color = when {
                        isVista -> Color.parseColor("#99FF5722")
                        isWasd -> Color.parseColor("#99008D94")
                        isFire -> Color.parseColor("#99FF2A55")
                        isAim -> Color.parseColor("#99FF9500")
                        else -> Color.parseColor("#9900F2FE")
                    }
                    setColor(color)
                    setStroke((1.5f * density).toInt(), Color.WHITE)
                }

                val tv = TextView(context).apply {
                    text = item.displayKey
                    setTextColor(Color.WHITE)
                    textSize = if (item.displayKey.length > 4) 8.5f else 11f
                    paint.isFakeBoldText = true
                    gravity = Gravity.CENTER
                    layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                }
                addView(tv)
            }

            val posX = (item.posXRatio * screenWidth - badgeSize / 2).toInt()
            val posY = (item.posYRatio * screenHeight - badgeSize / 2).toInt()

            val lp = FrameLayout.LayoutParams(badgeSize, badgeSize).apply {
                gravity = Gravity.TOP or Gravity.START
                leftMargin = posX
                topMargin = posY
            }

            if (isEditModeActive) {
                buttonView.setOnTouchListener(object : View.OnTouchListener {
                    private var startX = 0
                    private var startY = 0
                    private var touchX = 0f
                    private var touchY = 0f
                    private var moved = false

                    override fun onTouch(v: View, event: MotionEvent): Boolean {
                        when (event.action) {
                            MotionEvent.ACTION_DOWN -> {
                                startX = lp.leftMargin
                                startY = lp.topMargin
                                touchX = event.rawX
                                touchY = event.rawY
                                moved = false
                                return true
                            }
                            MotionEvent.ACTION_MOVE -> {
                                val dx = (event.rawX - touchX).toInt()
                                val dy = (event.rawY - touchY).toInt()
                                if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) {
                                    moved = true
                                    lp.leftMargin = (startX + dx).coerceIn(0, screenWidth - badgeSize)
                                    lp.topMargin = (startY + dy).coerceIn(0, screenHeight - badgeSize)
                                    buttonView.layoutParams = lp
                                }
                                return true
                            }
                            MotionEvent.ACTION_UP -> {
                                if (moved) {
                                    val newXRatio = (lp.leftMargin + badgeSize / 2f) / screenWidth
                                    val newYRatio = (lp.topMargin + badgeSize / 2f) / screenHeight
                                    updateMappingPosition(item.id, newXRatio, newYRatio)
                                } else {
                                    // Clique: abre o inspetor de configurações do botão
                                    openInspectorFor(item)
                                }
                                return true
                            }
                        }
                        return false
                    }
                })
            }

            container.addView(buttonView, lp)
        }
    }

    private fun updateMappingPosition(mappingId: String, xRatio: Float, yRatio: Float) {
        val profile = currentProfile ?: return
        val updated = profile.mappings.map {
            if (it.id == mappingId) it.copy(posXRatio = xRatio, posYRatio = yRatio) else it
        }
        currentProfile = profile.copy(mappings = updated)
    }

    private fun addNewButtonMapping(label: String, type: MappingType, keyCode: Int, displayKey: String, radius: Float = 0.06f): KeyMappingItem {
        val profile = currentProfile ?: return KeyMappingItem("temp", label, type, keyCode, displayKey, 0.5f, 0.5f)
        val newItem = KeyMappingItem(
            id = "map_${UUID.randomUUID().toString().take(6)}",
            label = label,
            type = type,
            keyCode = keyCode,
            displayKey = displayKey,
            posXRatio = 0.5f,
            posYRatio = 0.5f,
            radiusRatio = radius,
            touchDelayMs = 25L
        )
        currentProfile = profile.copy(mappings = profile.mappings + newItem)
        renderOverlayButtons()
        Toast.makeText(this, "Adicionado: $displayKey", Toast.LENGTH_SHORT).show()
        return newItem
    }

    private fun saveProfileChanges() {
        val profile = currentProfile ?: return
        scope.launch(Dispatchers.IO) {
            val db = AppDatabase.getInstance(applicationContext)
            val repo = GameProfileRepository(db.gameProfileDao())
            repo.saveProfile(profile)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        val wm = windowManager ?: return
        floatingBubble?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        compactToolbar?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        overlayButtonsContainer?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        inspectorDialogView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
    }
}
