package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class KeyMapperAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isActive.value = true
        Log.d(TAG, "KeyMapperAccessibilityService conectado com sucesso!")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Observa mudanças de janela se necessário
    }

    override fun onInterrupt() {
        Log.w(TAG, "KeyMapperAccessibilityService interrompido.")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isActive.value = false
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Notifica listeners (se ativado pelo usuário para mapeamento global)
        keyEventListener?.invoke(event)
        return super.onKeyEvent(event)
    }

    fun injectTap(x: Float, y: Float, durationMs: Long = 40L): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply {
            moveTo(x.coerceAtLeast(0f), y.coerceAtLeast(0f))
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(10L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun injectSwipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 80L): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(20L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    companion object {
        private const val TAG = "KeyMapperService"
        var instance: KeyMapperAccessibilityService? = null
            private set

        private val _isActive = MutableStateFlow(false)
        val isActive: StateFlow<Boolean> = _isActive.asStateFlow()

        var keyEventListener: ((KeyEvent) -> Unit)? = null

        fun isRunning(): Boolean = instance != null
    }
}
