package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.GameProfile
import com.example.model.KeyMappingItem
import com.example.model.MappingType
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "game_profiles")
data class GameProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val genre: String,
    val packageName: String,
    val mouseSensitivityX: Float,
    val mouseSensitivityY: Float,
    val adsSensitivityModifier: Float,
    val pointerSpeed: Float,
    val cursorLockKey: String,
    val crosshairStyle: String,
    val crosshairColorHex: String,
    val crosshairSizeDp: Int,
    val antiRecoilPullDown: Float,
    val isSmoothAim: Boolean,
    val isFavorite: Boolean,
    val mappingsJson: String,
    val updatedAt: Long
) {
    fun toDomain(): GameProfile {
        val mappingList = mutableListOf<KeyMappingItem>()
        try {
            val jsonArray = JSONArray(mappingsJson)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                mappingList.add(
                    KeyMappingItem(
                        id = obj.optString("id", "item_$i"),
                        label = obj.optString("label", "Tecla"),
                        type = try {
                            MappingType.valueOf(obj.optString("type", MappingType.BUTTON.name))
                        } catch (e: Exception) {
                            MappingType.BUTTON
                        },
                        keyCode = obj.optInt("keyCode", 0),
                        displayKey = obj.optString("displayKey", "?"),
                        posXRatio = obj.optDouble("posXRatio", 0.5).toFloat(),
                        posYRatio = obj.optDouble("posYRatio", 0.5).toFloat(),
                        radiusRatio = obj.optDouble("radiusRatio", 0.06).toFloat(),
                        touchDelayMs = obj.optLong("touchDelayMs", 25L),
                        secondaryKeyCode = obj.optInt("secondaryKeyCode", 0),
                        isHoldMode = obj.optBoolean("isHoldMode", true),
                        customAction = obj.optString("customAction", "")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return GameProfile(
            id = id,
            name = name,
            genre = genre,
            packageName = packageName,
            mouseSensitivityX = mouseSensitivityX,
            mouseSensitivityY = mouseSensitivityY,
            adsSensitivityModifier = adsSensitivityModifier,
            pointerSpeed = pointerSpeed,
            cursorLockKey = cursorLockKey,
            crosshairStyle = crosshairStyle,
            crosshairColorHex = crosshairColorHex,
            crosshairSizeDp = crosshairSizeDp,
            antiRecoilPullDown = antiRecoilPullDown,
            isSmoothAim = isSmoothAim,
            isFavorite = isFavorite,
            mappings = mappingList,
            updatedAt = updatedAt
        )
    }

    companion object {
        fun fromDomain(profile: GameProfile): GameProfileEntity {
            val jsonArray = JSONArray()
            for (item in profile.mappings) {
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("label", item.label)
                obj.put("type", item.type.name)
                obj.put("keyCode", item.keyCode)
                obj.put("displayKey", item.displayKey)
                obj.put("posXRatio", item.posXRatio.toDouble())
                obj.put("posYRatio", item.posYRatio.toDouble())
                obj.put("radiusRatio", item.radiusRatio.toDouble())
                obj.put("touchDelayMs", item.touchDelayMs)
                obj.put("secondaryKeyCode", item.secondaryKeyCode)
                obj.put("isHoldMode", item.isHoldMode)
                obj.put("customAction", item.customAction)
                jsonArray.put(obj)
            }

            return GameProfileEntity(
                id = profile.id,
                name = profile.name,
                genre = profile.genre,
                packageName = profile.packageName,
                mouseSensitivityX = profile.mouseSensitivityX,
                mouseSensitivityY = profile.mouseSensitivityY,
                adsSensitivityModifier = profile.adsSensitivityModifier,
                pointerSpeed = profile.pointerSpeed,
                cursorLockKey = profile.cursorLockKey,
                crosshairStyle = profile.crosshairStyle,
                crosshairColorHex = profile.crosshairColorHex,
                crosshairSizeDp = profile.crosshairSizeDp,
                antiRecoilPullDown = profile.antiRecoilPullDown,
                isSmoothAim = profile.isSmoothAim,
                isFavorite = profile.isFavorite,
                mappingsJson = jsonArray.toString(),
                updatedAt = profile.updatedAt
            )
        }
    }
}
