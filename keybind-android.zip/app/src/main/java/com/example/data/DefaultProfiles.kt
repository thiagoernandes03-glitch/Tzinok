package com.example.data

import android.view.KeyEvent
import com.example.model.GameProfile
import com.example.model.KeyMappingItem
import com.example.model.MappingType

object DefaultProfiles {

    fun getDefaults(): List<GameProfile> {
        return listOf(
            createFreeFireProfile(),
            createPubgProfile(),
            createCodMobileProfile(),
            createMinecraftProfile(),
            createCustomProfile()
        )
    }

    fun createFreeFireProfile(): GameProfile {
        val mappings = listOf(
            // Movement - DPad WASD (Left side, centered vertically)
            KeyMappingItem(
                id = "ff_wasd",
                label = "Movimento (WASD)",
                type = MappingType.DPAD_WASD,
                keyCode = KeyEvent.KEYCODE_W,
                displayKey = "WASD",
                posXRatio = 0.18f,
                posYRatio = 0.70f,
                radiusRatio = 0.12f,
                secondaryKeyCode = KeyEvent.KEYCODE_SHIFT_LEFT
            ),
            // Mouse Look / Camera Aim (Right side)
            KeyMappingItem(
                id = "ff_mouse_look",
                label = "Câmera / Mira FPS",
                type = MappingType.MOUSE_LOOK,
                keyCode = KeyEvent.KEYCODE_GRAVE, // ~ Tilde toggle
                displayKey = "MIRA (~) ",
                posXRatio = 0.65f,
                posYRatio = 0.45f,
                radiusRatio = 0.20f
            ),
            // Primary Fire - Left Mouse Click
            KeyMappingItem(
                id = "ff_fire",
                label = "Atirar (Disparo)",
                type = MappingType.FIRE_BUTTON,
                keyCode = KeyMappingItem.KEY_CODE_MOUSE_LEFT,
                displayKey = "L-CLICK",
                posXRatio = 0.88f,
                posYRatio = 0.58f,
                radiusRatio = 0.08f
            ),
            // ADS Scope - Right Mouse Click
            KeyMappingItem(
                id = "ff_aim",
                label = "Mirar (Mira Óptica)",
                type = MappingType.AIM_BUTTON,
                keyCode = KeyMappingItem.KEY_CODE_MOUSE_RIGHT,
                displayKey = "R-CLICK",
                posXRatio = 0.82f,
                posYRatio = 0.40f,
                radiusRatio = 0.07f
            ),
            // Jump - Space
            KeyMappingItem(
                id = "ff_jump",
                label = "Pular",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_SPACE,
                displayKey = "ESPAÇO",
                posXRatio = 0.92f,
                posYRatio = 0.76f,
                radiusRatio = 0.06f
            ),
            // Crouch - C
            KeyMappingItem(
                id = "ff_crouch",
                label = "Abaixar",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_C,
                displayKey = "C",
                posXRatio = 0.84f,
                posYRatio = 0.88f,
                radiusRatio = 0.06f
            ),
            // Prone - Z
            KeyMappingItem(
                id = "ff_prone",
                label = "Deitar",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_Z,
                displayKey = "Z",
                posXRatio = 0.74f,
                posYRatio = 0.90f,
                radiusRatio = 0.05f
            ),
            // Reload - R
            KeyMappingItem(
                id = "ff_reload",
                label = "Recarregar",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_R,
                displayKey = "R",
                posXRatio = 0.75f,
                posYRatio = 0.22f,
                radiusRatio = 0.06f
            ),
            // Weapon 1
            KeyMappingItem(
                id = "ff_w1",
                label = "Arma 1",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_1,
                displayKey = "1",
                posXRatio = 0.52f,
                posYRatio = 0.16f,
                radiusRatio = 0.05f
            ),
            // Weapon 2
            KeyMappingItem(
                id = "ff_w2",
                label = "Arma 2",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_2,
                displayKey = "2",
                posXRatio = 0.62f,
                posYRatio = 0.16f,
                radiusRatio = 0.05f
            ),
            // Weapon 3 (Melee/Pistol)
            KeyMappingItem(
                id = "ff_w3",
                label = "Pistola / Faca",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_3,
                displayKey = "3",
                posXRatio = 0.72f,
                posYRatio = 0.16f,
                radiusRatio = 0.05f
            ),
            // Interact / Loot - F
            KeyMappingItem(
                id = "ff_loot",
                label = "Pegar Item / Abrir",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_F,
                displayKey = "F",
                posXRatio = 0.65f,
                posYRatio = 0.30f,
                radiusRatio = 0.05f
            ),
            // Medical Kit - 4
            KeyMappingItem(
                id = "ff_med",
                label = "Kit Médico",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_4,
                displayKey = "4",
                posXRatio = 0.08f,
                posYRatio = 0.48f,
                radiusRatio = 0.05f
            ),
            // Backpack - Tab
            KeyMappingItem(
                id = "ff_bag",
                label = "Mochila",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_TAB,
                displayKey = "TAB",
                posXRatio = 0.08f,
                posYRatio = 0.62f,
                radiusRatio = 0.05f
            ),
            // Map - M
            KeyMappingItem(
                id = "ff_map",
                label = "Mapa",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_M,
                displayKey = "M",
                posXRatio = 0.08f,
                posYRatio = 0.15f,
                radiusRatio = 0.06f
            ),
            // Sprint - Shift
            KeyMappingItem(
                id = "ff_sprint",
                label = "Correr Rápido",
                type = MappingType.BUTTON,
                keyCode = KeyEvent.KEYCODE_SHIFT_LEFT,
                displayKey = "SHIFT",
                posXRatio = 0.22f,
                posYRatio = 0.46f,
                radiusRatio = 0.05f
            )
        )

        return GameProfile(
            id = "profile_free_fire",
            name = "Free Fire MAX",
            genre = "Battle Royale",
            packageName = "com.dts.freefireth",
            mouseSensitivityX = 1.35f,
            mouseSensitivityY = 1.10f,
            adsSensitivityModifier = 0.80f,
            pointerSpeed = 1.0f,
            cursorLockKey = "~",
            crosshairStyle = "TACTICAL",
            crosshairColorHex = "#00F2FE",
            crosshairSizeDp = 26,
            antiRecoilPullDown = 0.18f,
            isFavorite = true,
            mappings = mappings
        )
    }

    fun createPubgProfile(): GameProfile {
        val mappings = listOf(
            KeyMappingItem("pubg_wasd", "Movimento", MappingType.DPAD_WASD, KeyEvent.KEYCODE_W, "WASD", 0.18f, 0.70f, 0.12f),
            KeyMappingItem("pubg_look", "Mira FPS", MappingType.MOUSE_LOOK, KeyEvent.KEYCODE_GRAVE, "MIRA (~)", 0.68f, 0.45f, 0.20f),
            KeyMappingItem("pubg_fire", "Disparo", MappingType.FIRE_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_LEFT, "L-CLICK", 0.88f, 0.58f, 0.08f),
            KeyMappingItem("pubg_aim", "Mirar (ADS)", MappingType.AIM_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_RIGHT, "R-CLICK", 0.84f, 0.40f, 0.07f),
            KeyMappingItem("pubg_jump", "Pular / Escalar", MappingType.BUTTON, KeyEvent.KEYCODE_SPACE, "ESPAÇO", 0.92f, 0.75f, 0.06f),
            KeyMappingItem("pubg_crouch", "Abaixar", MappingType.BUTTON, KeyEvent.KEYCODE_C, "C", 0.84f, 0.88f, 0.06f),
            KeyMappingItem("pubg_prone", "Deitar", MappingType.BUTTON, KeyEvent.KEYCODE_Z, "Z", 0.74f, 0.90f, 0.05f),
            KeyMappingItem("pubg_lean_l", "Inclinar Esquerda", MappingType.BUTTON, KeyEvent.KEYCODE_Q, "Q", 0.28f, 0.38f, 0.05f),
            KeyMappingItem("pubg_lean_r", "Inclinar Direita", MappingType.BUTTON, KeyEvent.KEYCODE_E, "E", 0.36f, 0.38f, 0.05f),
            KeyMappingItem("pubg_reload", "Recarregar", MappingType.BUTTON, KeyEvent.KEYCODE_R, "R", 0.75f, 0.24f, 0.06f),
            KeyMappingItem("pubg_w1", "Arma Primária", MappingType.BUTTON, KeyEvent.KEYCODE_1, "1", 0.50f, 0.88f, 0.05f),
            KeyMappingItem("pubg_w2", "Arma Secundária", MappingType.BUTTON, KeyEvent.KEYCODE_2, "2", 0.60f, 0.88f, 0.05f),
            KeyMappingItem("pubg_loot", "Interagir / Saquear", MappingType.BUTTON, KeyEvent.KEYCODE_F, "F", 0.68f, 0.32f, 0.05f),
            KeyMappingItem("pubg_bag", "Mochila", MappingType.BUTTON, KeyEvent.KEYCODE_TAB, "TAB", 0.08f, 0.75f, 0.05f),
            KeyMappingItem("pubg_map", "Mapa Geral", MappingType.BUTTON, KeyEvent.KEYCODE_M, "M", 0.90f, 0.12f, 0.06f)
        )

        return GameProfile(
            id = "profile_pubg",
            name = "PUBG Mobile / BGMI",
            genre = "Battle Royale",
            packageName = "com.tencent.ig",
            mouseSensitivityX = 1.25f,
            mouseSensitivityY = 1.05f,
            adsSensitivityModifier = 0.70f,
            pointerSpeed = 1.0f,
            cursorLockKey = "Ctrl",
            crosshairStyle = "CROSS",
            crosshairColorHex = "#FF5722",
            crosshairSizeDp = 24,
            antiRecoilPullDown = 0.22f,
            isFavorite = true,
            mappings = mappings
        )
    }

    fun createCodMobileProfile(): GameProfile {
        val mappings = listOf(
            KeyMappingItem("cod_wasd", "Movimento", MappingType.DPAD_WASD, KeyEvent.KEYCODE_W, "WASD", 0.18f, 0.70f, 0.12f),
            KeyMappingItem("cod_look", "Câmera", MappingType.MOUSE_LOOK, KeyEvent.KEYCODE_GRAVE, "MIRA (~)", 0.65f, 0.45f, 0.20f),
            KeyMappingItem("cod_fire", "Disparo", MappingType.FIRE_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_LEFT, "L-CLICK", 0.88f, 0.58f, 0.08f),
            KeyMappingItem("cod_aim", "Mirar (ADS)", MappingType.AIM_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_RIGHT, "R-CLICK", 0.82f, 0.40f, 0.07f),
            KeyMappingItem("cod_jump", "Pulo / Slide", MappingType.BUTTON, KeyEvent.KEYCODE_SPACE, "ESPAÇO", 0.92f, 0.75f, 0.06f),
            KeyMappingItem("cod_crouch", "Deslizar / Agachar", MappingType.BUTTON, KeyEvent.KEYCODE_C, "C", 0.84f, 0.88f, 0.06f),
            KeyMappingItem("cod_reload", "Recarga Rápida", MappingType.BUTTON, KeyEvent.KEYCODE_R, "R", 0.76f, 0.24f, 0.06f),
            KeyMappingItem("cod_skill", "Habilidade Operador", MappingType.BUTTON, KeyEvent.KEYCODE_Q, "Q", 0.80f, 0.15f, 0.05f),
            KeyMappingItem("cod_grenade", "Granada Tática", MappingType.BUTTON, KeyEvent.KEYCODE_G, "G", 0.70f, 0.75f, 0.05f),
            KeyMappingItem("cod_streak", "Scorestreak", MappingType.BUTTON, KeyEvent.KEYCODE_4, "4", 0.50f, 0.78f, 0.05f)
        )

        return GameProfile(
            id = "profile_cod",
            name = "Call of Duty: Mobile",
            genre = "FPS Multiplayer",
            packageName = "com.activision.callofduty.shooter",
            mouseSensitivityX = 1.40f,
            mouseSensitivityY = 1.15f,
            adsSensitivityModifier = 0.85f,
            pointerSpeed = 1.0f,
            cursorLockKey = "~",
            crosshairStyle = "DOT",
            crosshairColorHex = "#00E676",
            crosshairSizeDp = 20,
            antiRecoilPullDown = 0.12f,
            isFavorite = false,
            mappings = mappings
        )
    }

    fun createMinecraftProfile(): GameProfile {
        val mappings = listOf(
            KeyMappingItem("mc_wasd", "Andar", MappingType.DPAD_WASD, KeyEvent.KEYCODE_W, "WASD", 0.20f, 0.70f, 0.12f),
            KeyMappingItem("mc_look", "Visão", MappingType.MOUSE_LOOK, KeyEvent.KEYCODE_GRAVE, "OLHAR (~)", 0.65f, 0.45f, 0.20f),
            KeyMappingItem("mc_attack", "Minerar / Bater", MappingType.BUTTON, KeyMappingItem.KEY_CODE_MOUSE_LEFT, "L-CLICK", 0.86f, 0.55f, 0.08f),
            KeyMappingItem("mc_use", "Colocar / Usar", MappingType.BUTTON, KeyMappingItem.KEY_CODE_MOUSE_RIGHT, "R-CLICK", 0.80f, 0.40f, 0.07f),
            KeyMappingItem("mc_jump", "Pular", MappingType.BUTTON, KeyEvent.KEYCODE_SPACE, "ESPAÇO", 0.88f, 0.75f, 0.07f),
            KeyMappingItem("mc_sneak", "Esgueirar", MappingType.BUTTON, KeyEvent.KEYCODE_SHIFT_LEFT, "SHIFT", 0.80f, 0.88f, 0.06f),
            KeyMappingItem("mc_inv", "Inventário", MappingType.BUTTON, KeyEvent.KEYCODE_E, "E", 0.48f, 0.90f, 0.06f),
            KeyMappingItem("mc_drop", "Largar Item", MappingType.BUTTON, KeyEvent.KEYCODE_Q, "Q", 0.38f, 0.90f, 0.05f)
        )

        return GameProfile(
            id = "profile_minecraft",
            name = "Minecraft Bedrock",
            genre = "Sandbox / Aventura",
            packageName = "com.mojang.minecraftpe",
            mouseSensitivityX = 1.0f,
            mouseSensitivityY = 1.0f,
            adsSensitivityModifier = 1.0f,
            pointerSpeed = 1.0f,
            cursorLockKey = "~",
            crosshairStyle = "CROSS",
            crosshairColorHex = "#FFFFFF",
            crosshairSizeDp = 22,
            antiRecoilPullDown = 0.0f,
            isFavorite = false,
            mappings = mappings
        )
    }

    fun createCustomProfile(): GameProfile {
        val mappings = listOf(
            KeyMappingItem("cust_wasd", "Joystick WASD", MappingType.DPAD_WASD, KeyEvent.KEYCODE_W, "WASD", 0.18f, 0.70f, 0.12f),
            KeyMappingItem("cust_look", "Mira do Mouse", MappingType.MOUSE_LOOK, KeyEvent.KEYCODE_GRAVE, "MIRA (~)", 0.65f, 0.45f, 0.20f),
            KeyMappingItem("cust_fire", "Disparo Principal", MappingType.FIRE_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_LEFT, "L-CLICK", 0.88f, 0.58f, 0.08f),
            KeyMappingItem("cust_aim", "Mira Óptica", MappingType.AIM_BUTTON, KeyMappingItem.KEY_CODE_MOUSE_RIGHT, "R-CLICK", 0.82f, 0.40f, 0.07f),
            KeyMappingItem("cust_jump", "Ação 1 (Pulo)", MappingType.BUTTON, KeyEvent.KEYCODE_SPACE, "ESPAÇO", 0.90f, 0.75f, 0.06f),
            KeyMappingItem("cust_action2", "Ação 2", MappingType.BUTTON, KeyEvent.KEYCODE_R, "R", 0.76f, 0.25f, 0.06f)
        )

        return GameProfile(
            id = "profile_custom",
            name = "Perfil Personalizado Gamer",
            genre = "Personalizado",
            packageName = "com.custom.game",
            mouseSensitivityX = 1.2f,
            mouseSensitivityY = 1.0f,
            adsSensitivityModifier = 0.8f,
            pointerSpeed = 1.0f,
            cursorLockKey = "~",
            crosshairStyle = "TACTICAL",
            crosshairColorHex = "#00F2FE",
            crosshairSizeDp = 24,
            antiRecoilPullDown = 0.10f,
            isFavorite = false,
            mappings = mappings
        )
    }
}
