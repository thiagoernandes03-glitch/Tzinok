package com.example.data

import com.example.model.GameProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class GameProfileRepository(private val dao: GameProfileDao) {

    val allProfiles: Flow<List<GameProfile>> = dao.getAllProfiles().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun getProfileById(id: String): GameProfile? = withContext(Dispatchers.IO) {
        dao.getProfileById(id)?.toDomain()
    }

    suspend fun saveProfile(profile: GameProfile) = withContext(Dispatchers.IO) {
        dao.insertOrUpdate(GameProfileEntity.fromDomain(profile.copy(updatedAt = System.currentTimeMillis())))
    }

    suspend fun deleteProfile(id: String) = withContext(Dispatchers.IO) {
        dao.deleteById(id)
    }

    suspend fun ensureDefaultsSeeded() = withContext(Dispatchers.IO) {
        val count = dao.getCount()
        if (count == 0) {
            val defaults = DefaultProfiles.getDefaults().map { GameProfileEntity.fromDomain(it) }
            dao.insertAll(defaults)
        }
    }

    suspend fun resetProfileToDefault(profileId: String) = withContext(Dispatchers.IO) {
        val default = DefaultProfiles.getDefaults().firstOrNull { it.id == profileId }
        if (default != null) {
            dao.insertOrUpdate(GameProfileEntity.fromDomain(default))
        }
    }
}
