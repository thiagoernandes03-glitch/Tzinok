package com.example.model

enum class MappingType {
    BUTTON,       // Single tap / action (e.g. Space, R, F, 1, 2, 3)
    DPAD_WASD,    // Virtual 8-direction movement stick (W, A, S, D)
    MOUSE_LOOK,   // FPS camera aiming via mouse delta movement
    FIRE_BUTTON,  // Primary weapon fire (Left Click)
    AIM_BUTTON,   // ADS scope zoom (Right Click)
    MACRO,        // Multi-touch combo sequence
    SWIPE         // Quick directional flick (e.g. peek/dodge)
}

data class KeyMappingItem(
    val id: String,
    val label: String,
    val type: MappingType,
    val keyCode: Int,            // Android KeyEvent.KEYCODE_* or custom code
    val displayKey: String,       // e.g., "W", "SPACE", "R", "L-CLICK", "R-CLICK", "SHIFT"
    val posXRatio: Float,         // 0.0f .. 1.0f (relative horizontal position)
    val posYRatio: Float,         // 0.0f .. 1.0f (relative vertical position)
    val radiusRatio: Float = 0.06f, // Relative size / touch radius
    val touchDelayMs: Long = 25L,   // Touch delay / duration in ms to prevent touch drops
    val secondaryKeyCode: Int = 0, // e.g. for Shift-sprint in WASD
    val isHoldMode: Boolean = true, // Continuous hold vs instant impulse
    val customAction: String = "" // Optional custom description
) {
    companion object {
        const val KEY_CODE_MOUSE_LEFT = -1001
        const val KEY_CODE_MOUSE_RIGHT = -1002
        const val KEY_CODE_MOUSE_MIDDLE = -1003
        const val KEY_CODE_MOUSE_WHEEL_UP = -1004
        const val KEY_CODE_MOUSE_WHEEL_DOWN = -1005
        const val KEY_CODE_MOUSE_BACK = -1006
        const val KEY_CODE_MOUSE_FORWARD = -1007
    }
}

data class GameProfile(
    val id: String,
    val name: String,
    val genre: String, // "FPS / Battle Royale", "MOBA", "Survival / Sandbox", "Ação"
    val packageName: String,
    val mouseSensitivityX: Float = 1.2f,
    val mouseSensitivityY: Float = 1.0f,
    val adsSensitivityModifier: Float = 0.75f,
    val pointerSpeed: Float = 1.0f,
    val cursorLockKey: String = "~",
    val crosshairStyle: String = "TACTICAL", // "NONE", "DOT", "CROSS", "TACTICAL", "CIRCLE"
    val crosshairColorHex: String = "#00F2FE",
    val crosshairSizeDp: Int = 26,
    val antiRecoilPullDown: Float = 0.15f,
    val isSmoothAim: Boolean = true,
    val isFavorite: Boolean = false,
    val mappings: List<KeyMappingItem> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class HardwareDeviceItem(
    val id: Int,
    val name: String,
    val vendorId: Int,
    val productId: Int,
    val isKeyboard: Boolean,
    val isMouse: Boolean,
    val isBluetooth: Boolean,
    val isUsb: Boolean,
    val keyCount: Int = 0,
    val hasScrollWheel: Boolean = false
)

data class InputTelemetryEvent(
    val timestamp: Long = System.currentTimeMillis(),
    val source: String,       // "TECLADO" or "MOUSE"
    val description: String,  // "Tecla W pressionada", "Clique Esquerdo", "Delta (14, -8)"
    val keyCode: Int = 0,
    val isDown: Boolean = true
)
