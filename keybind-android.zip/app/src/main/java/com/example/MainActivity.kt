package com.example

import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.KeyMapperApp
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.KeyMapperViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: KeyMapperViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KeyMapperApp(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkOverlayPermission()
        viewModel.refreshShizukuStatus()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val handled = viewModel.handleKeyEvent(event)
        if (handled) return true
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        val handled = viewModel.handleMotionEvent(event)
        if (handled) return true
        return super.dispatchGenericMotionEvent(event)
    }
}
