package com.example.hardware

import android.content.Context
import android.hardware.input.InputManager
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import com.example.model.HardwareDeviceItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class InputDeviceDetector(private val context: Context) : InputManager.InputDeviceListener {

    private val inputManager = context.getSystemService(Context.INPUT_SERVICE) as InputManager
    private val handler = Handler(Looper.getMainLooper())

    private val _connectedKeyboards = MutableStateFlow<List<HardwareDeviceItem>>(emptyList())
    val connectedKeyboards: StateFlow<List<HardwareDeviceItem>> = _connectedKeyboards.asStateFlow()

    private val _connectedMice = MutableStateFlow<List<HardwareDeviceItem>>(emptyList())
    val connectedMice: StateFlow<List<HardwareDeviceItem>> = _connectedMice.asStateFlow()

    private val _hasHardwareKeyboard = MutableStateFlow(false)
    val hasHardwareKeyboard: StateFlow<Boolean> = _hasHardwareKeyboard.asStateFlow()

    private val _hasHardwareMouse = MutableStateFlow(false)
    val hasHardwareMouse: StateFlow<Boolean> = _hasHardwareMouse.asStateFlow()

    fun startListening() {
        inputManager.registerInputDeviceListener(this, handler)
        refreshDevices()
    }

    fun stopListening() {
        inputManager.unregisterInputDeviceListener(this)
    }

    fun refreshDevices() {
        val keyboards = mutableListOf<HardwareDeviceItem>()
        val mice = mutableListOf<HardwareDeviceItem>()

        val deviceIds = inputManager.inputDeviceIds
        for (id in deviceIds) {
            val device = inputManager.getInputDevice(id) ?: continue

            // Ignora dispositivos puramente virtuais gerados por software interno se não tiverem teclas
            val isVirtual = device.isVirtual
            val sources = device.sources

            val hasKeyboardSource = (sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD
            val hasMouseSource = (sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
                    (sources and InputDevice.SOURCE_TOUCHPAD) == InputDevice.SOURCE_TOUCHPAD

            val isLikelyPhysicalKeyboard = hasKeyboardSource && (device.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC)
            val isLikelyPhysicalMouse = hasMouseSource

            val item = HardwareDeviceItem(
                id = device.id,
                name = device.name ?: "Dispositivo USB/BT",
                vendorId = device.vendorId,
                productId = device.productId,
                isKeyboard = isLikelyPhysicalKeyboard,
                isMouse = isLikelyPhysicalMouse,
                isBluetooth = device.name.contains("Bluetooth", ignoreCase = true) || device.vendorId == 0,
                isUsb = !isVirtual && (device.vendorId > 0),
                hasScrollWheel = (sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE
            )

            if (isLikelyPhysicalKeyboard) {
                keyboards.add(item)
            }
            if (isLikelyPhysicalMouse) {
                mice.add(item)
            }
        }

        _connectedKeyboards.value = keyboards
        _connectedMice.value = mice
        _hasHardwareKeyboard.value = keyboards.isNotEmpty()
        _hasHardwareMouse.value = mice.isNotEmpty()
    }

    override fun onInputDeviceAdded(deviceId: Int) {
        refreshDevices()
    }

    override fun onInputDeviceRemoved(deviceId: Int) {
        refreshDevices()
    }

    override fun onInputDeviceChanged(deviceId: Int) {
        refreshDevices()
    }
}
